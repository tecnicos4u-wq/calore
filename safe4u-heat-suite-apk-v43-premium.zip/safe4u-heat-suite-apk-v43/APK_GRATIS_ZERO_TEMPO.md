# Ottenere l'APK gratis caricando lo ZIP online

Metodo più rapido e gratuito: GitHub + GitHub Actions.

## Procedura operativa

1. Crea un account gratuito su GitHub.
2. Crea un nuovo repository, anche pubblico se vuoi usare minuti Actions gratuiti senza consumo del piano privato.
3. Scompatta questo ZIP sul tuo PC.
4. Carica nel repository tutto il contenuto della cartella `safe4u-heat-suite-apk-v43`.
5. Vai nella scheda **Actions** del repository.
6. Apri il workflow **Build Safe4U Heat Check Debug APK**.
7. Clicca **Run workflow**.
8. A fine build scarica l'artefatto **Safe4U-HeatCheck-debug-apk**.
9. Dentro trovi `app-debug.apk`.
10. Installa l'APK su Android abilitando l'installazione da sorgenti sconosciute.

## Importante

- Questo genera un APK debug, utile per test immediato su telefoni Android.
- Per Google Play serve una release firmata e preferibilmente AAB, non il solo APK debug.
- Per una release professionale servono keystore, versione, privacy policy, data safety e test.
- La build richiede che GitHub scarichi Node, Java, Android SDK, Gradle e dipendenze Capacitor; non è istantanea al secondo, ma normalmente richiede pochi minuti.

## Alternativa

Servizi simili: Appcircle, Codemagic, Bitrise. Sono validi ma GitHub Actions è la strada più semplice perché il workflow è già incluso nello ZIP.

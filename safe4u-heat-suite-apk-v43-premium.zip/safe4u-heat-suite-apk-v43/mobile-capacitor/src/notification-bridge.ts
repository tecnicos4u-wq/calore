import { LocalNotifications } from '@capacitor/local-notifications';

export type HeatAlert = {
  id: number;
  title: string;
  body: string;
  when: Date;
  severity?: 'info' | 'warning' | 'danger';
};

export async function requestHeatNotificationPermission(): Promise<boolean> {
  const result = await LocalNotifications.requestPermissions();
  return result.display === 'granted';
}

export async function createHeatChannels(): Promise<void> {
  await LocalNotifications.createChannel({
    id: 'heat-critical',
    name: 'Safe 4 U - Stop operativo caldo',
    description: 'Allert critici su stop 12:30-16:00 e preavvisi rossi',
    importance: 5,
    visibility: 1,
    vibration: true
  });
  await LocalNotifications.createChannel({
    id: 'heat-check',
    name: 'Safe 4 U - Controlli rischio caldo',
    description: 'Verifica Worklimate, misure, ripresa e registro',
    importance: 4,
    visibility: 1,
    vibration: true
  });
}

export async function scheduleHeatAlerts(alerts: HeatAlert[]): Promise<void> {
  await createHeatChannels();
  await LocalNotifications.schedule({
    notifications: alerts.map(a => ({
      id: a.id,
      title: a.title,
      body: a.body,
      schedule: { at: a.when },
      channelId: a.severity === 'danger' ? 'heat-critical' : 'heat-check',
      autoCancel: true,
      ongoing: false
    }))
  });
}

export async function cancelHeatAlerts(): Promise<void> {
  const pending = await LocalNotifications.getPending();
  await LocalNotifications.cancel({ notifications: pending.notifications });
}

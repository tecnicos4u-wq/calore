import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'it.safe4u.heatcheck',
  appName: 'Safe 4 U Heat Check',
  webDir: '../frontend',
  bundledWebRuntime: false,
  plugins: {
    LocalNotifications: {
      smallIcon: 'ic_stat_safe4u',
      iconColor: '#111a4c'
    }
  }
};

export default config;

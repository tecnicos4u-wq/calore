# Safe 4 U Heat Suite v4.3 Premium

Versione con DVR premium migliorato, immagini/grafici integrati e workflow GitHub Actions per generare APK debug gratuitamente.

File chiave:
- `examples/DVR_Calore_Safe4U_Esempio_v43_PREMIUM.docx`
- `examples/DVR_Calore_Safe4U_Esempio_v43_PREMIUM.pdf`
- `client_formats/Safe4U_Format_Cliente_Calore.zip`
- `APK_GRATIS_ZERO_TEMPO.md`

# Safe 4 U Heat DVR Suite

Suite MVP avanzata v4.2 per:

- generare un DVR calore/radiazione solare in DOCX con logo Safe 4 U Evolution, grafici, immagini, tabelle e conclusioni;
- acquisire in drag & drop i format cliente restituiti, visura, DVR generale, elenco lavoratori, screenshot Worklimate, planimetrie, foto misure, nomine e procedure;
- calcolare indice operativo aziendale rischio calore;
- verificare trigger Ordinanza Lombardia n. 484/2026;
- usare il telefono come check operativo per capire se si può lavorare, quando fermarsi, quando riprendere e quali misure applicare;
- generare allert/notifiche sul cellulare per verifica Worklimate, preavviso stop, stop 12:30, ripresa 16:00 e monitoraggio misure;
- predisporre build APK Android tramite Capacitor e workflow CI.

## Avvio backend

```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

## Avvio frontend

```bash
cd frontend
python -m http.server 8080
```

Aprire `http://localhost:8080`.

## Funzioni implementate

### Format cliente

Nella cartella `client_formats/` sono presenti i format A-G da inviare al cliente. Lo ZIP è anche disponibile nel frontend: `frontend/formats/Safe4U_Format_Cliente_Calore.zip`. Il DVR finale non stampa l'elenco A-G: i format servono alla raccolta dati e restano nel fascicolo tecnico.

### APK Android

La cartella `mobile-capacitor/` contiene la base per generare APK Android. La cartella `android_apk_build/` contiene istruzioni di build debug/release. In questo ambiente non è stato compilato un APK perché non sono disponibili Android SDK/Gradle.

## Funzioni implementate

- Wizard in 7 step.
- Tasto Help sempre visibile.
- Drag & drop visura con estrazione dati.
- Drag & drop documenti multipli con categorizzazione.
- Import CSV lavoratori.
- Geolocalizzazione foreground.
- Rischio Worklimate automatico best-effort o manuale.
- Anteprima calcoli e checklist.
- Generazione DVR DOCX con grafici e immagini.
- Centro Allerte telefono con permesso notifiche, test allert, piano giornaliero e scheduling locale.
- Sezione DVR dedicata ad app Android, notifiche e tracciabilità operativa.

## Output DVR

Il DOCX contiene:

1. copertina grafica Safe 4 U;
2. controllo documento;
3. indice operativo;
4. executive summary;
5. quadro normativo;
6. anagrafica azienda;
7. documenti caricati in drag & drop;
8. descrizione sito e dati locali;
9. metodologia con R = P x D x C, Humidex e WBGT;
10. timeline operativa, matrice rischio, grafici per mansione;
11. calcoli iniziali e residui;
12. applicazione ordinanza Lombardia;
13. misure prevenzione/protezione;
14. procedura giornaliera;
15. emergenza caldo;
16. formazione/sorveglianza sanitaria;
17. piano miglioramento;
18. allert smartphone e tracciabilità;
19. allegati, conclusioni e firme.

## Nota

Il software è un MVP evoluto: prima dell'uso produttivo servono hardening sicurezza, autenticazione, audit log, storage documentale, policy privacy, test Android e validazione tecnico-legale del modello finale.

## Allert cellulare

La schermata **Allerte** programma promemoria locali per il telefono: 10:30 pre-check, 12:00 Worklimate, 12:20 preavviso, 12:30 stop/controllo, 16:00 ripresa e monitoraggi periodici. Nel prototipo web/PWA funzionano tramite Notification API + Service Worker; nella build Android Google Play vanno convertiti in notifiche locali native persistenti. Vedere `docs/ALERTS_ANDROID.md`.

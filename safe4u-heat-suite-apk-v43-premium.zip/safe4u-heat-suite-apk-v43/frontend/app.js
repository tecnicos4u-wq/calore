const DEFAULT_API = 'http://localhost:8000';
let API = localStorage.getItem('SAFE4U_HEAT_API') || DEFAULT_API;
let currentStep = 0;
let employees = [];
let documentsStore = [];
let worklimateResults = [];
let lastPreview = null;
let visuraFile = null;
let alertPlan = [];
let alertTimers = [];

const $ = (id) => document.getElementById(id);
const value = (id) => ($(id)?.value || '').trim();
const checked = (id) => Boolean($(id)?.checked);
const setValue = (id, val) => { if ($(id) && val !== undefined && val !== null) $(id).value = val; };
const setChecked = (id, val) => { if ($(id) && val !== undefined && val !== null) $(id).checked = Boolean(val); };
const num = (id) => value(id) === '' ? null : Number(value(id));

const RISK_ORDER = { NON_DISPONIBILE: 0, BASSO: 1, MODERATO: 2, ALTO: 3 };
const DOC_CATEGORIES = [
  ['visura_camerale', 'Visura camerale'],
  ['dvr_generale', 'DVR generale'],
  ['ordinanza', 'Ordinanza'],
  ['screenshot_worklimate', 'Screenshot Worklimate'],
  ['elenco_lavoratori', 'Elenco lavoratori'],
  ['planimetria_o_layout', 'Planimetria/layout'],
  ['foto_misure', 'Foto misure'],
  ['nomine_sicurezza', 'Nomine sicurezza'],
  ['procedure', 'Procedure'],
  ['altro', 'Altro'],
];

function init() {
  $('api_base').value = API;
  bindEvents();
  loadLocalDraft();
  updateStep();
  initAlertsUI();
  refreshUI();
}

function bindEvents() {
  $('api_base').addEventListener('change', () => {
    API = value('api_base') || DEFAULT_API;
    localStorage.setItem('SAFE4U_HEAT_API', API);
    toast(`API impostata: ${API}`);
  });

  document.querySelectorAll('.step').forEach(btn => btn.addEventListener('click', () => { currentStep = Number(btn.dataset.step); updateStep(); }));
  $('prev_step').addEventListener('click', () => { currentStep = Math.max(0, currentStep - 1); updateStep(); });
  $('next_step').addEventListener('click', () => { currentStep = Math.min(6, currentStep + 1); updateStep(); });

  $('browse_visura').addEventListener('click', () => $('visura_file').click());
  $('browse_docs').addEventListener('click', () => $('docs_file').click());
  $('visura_file').addEventListener('change', e => handleVisuraFiles(e.target.files));
  $('docs_file').addEventListener('change', e => handleDocumentFiles(e.target.files));
  setupDropzone('visura_drop', files => handleVisuraFiles(files));
  setupDropzone('docs_drop', files => handleDocumentFiles(files));
  $('extract_visura').addEventListener('click', extractVisura);
  $('clear_docs').addEventListener('click', () => { documentsStore = []; visuraFile = null; renderDocuments(); saveLocalDraft(false); refreshUI(); });

  $('geo_button').addEventListener('click', getPhonePosition);
  $('risk_button').addEventListener('click', fetchWorklimateRisk);
  $('apply_manual_risk').addEventListener('click', applyManualRisk);
  $('preview_site').addEventListener('click', () => previewRisk(true));
  $('preview_button').addEventListener('click', () => previewRisk(true));
  $('checklist_button').addEventListener('click', dailyChecklist);
  $('notification_permission').addEventListener('click', requestNotificationPermission);
  $('test_notification').addEventListener('click', testNotification);
  $('build_alert_plan').addEventListener('click', () => { const plan = buildAlertPlan(true); renderAlertPlan(plan); toast('Piano allerte generato.'); });
  $('schedule_alerts').addEventListener('click', schedulePhoneAlerts);
  $('cancel_alerts').addEventListener('click', cancelScheduledAlerts);
  $('add_emp').addEventListener('click', addEmployee);
  $('add_emp_demo').addEventListener('click', addDemoEmployees);
  $('csv_file').addEventListener('change', importCSVFromInput);
  $('generate_button').addEventListener('click', generateDVR);
  $('export_json').addEventListener('click', exportJSON);
  $('json_file').addEventListener('change', importJSON);
  $('load_sample').addEventListener('click', loadSample);
  $('save_local').addEventListener('click', () => saveLocalDraft(true));
  $('reset_all').addEventListener('click', clearAll);

  $('help_fab').addEventListener('click', () => openHelp(currentHelpKey()));
  $('close_help').addEventListener('click', () => $('help_dialog').close());
  document.querySelectorAll('[data-help]').forEach(btn => btn.addEventListener('click', () => openHelp(btn.dataset.help)));

  document.querySelectorAll('input, textarea, select').forEach(el => {
    if (el.type !== 'file') {
      el.addEventListener('input', debounce(() => { refreshUI(); saveLocalDraft(false); }, 250));
      el.addEventListener('change', debounce(() => { refreshUI(); saveLocalDraft(false); }, 250));
    }
  });
}

function updateStep() {
  document.querySelectorAll('.step').forEach((btn, i) => btn.classList.toggle('active', i === currentStep));
  document.querySelectorAll('.panel').forEach((p, i) => p.classList.toggle('active', i === currentStep));
  $('prev_step').disabled = currentStep === 0;
  $('next_step').textContent = currentStep === 6 ? 'Fine' : 'Avanti';
  refreshUI();
}

function setupDropzone(id, callback) {
  const dz = $(id);
  ['dragenter', 'dragover'].forEach(evt => dz.addEventListener(evt, e => { e.preventDefault(); dz.classList.add('dragover'); }));
  ['dragleave', 'drop'].forEach(evt => dz.addEventListener(evt, e => { e.preventDefault(); dz.classList.remove('dragover'); }));
  dz.addEventListener('drop', e => callback(e.dataTransfer.files));
  dz.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') dz.querySelector('input[type="file"]').click(); });
}

async function handleVisuraFiles(files) {
  if (!files || !files.length) return;
  visuraFile = files[0];
  await addDocumentFromFile(visuraFile, 'visura_camerale', 'Visura camerale per estrazione dati aziendali');
  $('visura_status').textContent = `Visura pronta: ${visuraFile.name}`;
  toast('Visura caricata. Premi “Estrai dati da visura”.');
}

async function handleDocumentFiles(files) {
  if (!files || !files.length) return;
  for (const file of Array.from(files)) {
    const cat = guessCategory(file.name, file.type);
    const attachment = await addDocumentFromFile(file, cat, 'Documento caricato in drag & drop');
    if (cat === 'elenco_lavoratori' && file.name.toLowerCase().endsWith('.csv')) {
      const text = await readAsText(file);
      importCSVText(text);
      attachment.extracted_text_preview = text.slice(0, 800);
    }
  }
  toast(`${files.length} documento/i acquisiti.`);
}

async function addDocumentFromFile(file, category = 'altro', description = '') {
  const existing = documentsStore.find(d => d.filename === file.name && d.size_bytes === file.size);
  if (existing) return existing;
  let dataUrl = null;
  let preview = '';
  const embedImages = checked('embed_images');
  if (file.type.startsWith('image/') && embedImages && file.size < 3.5 * 1024 * 1024) {
    dataUrl = await readAsDataURL(file);
  }
  if (file.type.startsWith('text/') || file.name.toLowerCase().endsWith('.csv') || file.name.toLowerCase().endsWith('.txt')) {
    preview = (await readAsText(file)).slice(0, 1200);
  }
  const attachment = {
    id: `doc-${Date.now()}-${Math.random().toString(16).slice(2)}`,
    filename: file.name,
    category,
    mime_type: file.type || mimeFromName(file.name),
    size_bytes: file.size,
    description,
    data_url: dataUrl,
    extracted_text_preview: preview,
    uploaded_at: new Date().toISOString(),
  };
  documentsStore.push(attachment);
  renderDocuments();
  saveLocalDraft(false);
  refreshUI();
  return attachment;
}

function renderDocuments() {
  const wrap = $('documents_list');
  wrap.innerHTML = '';
  $('doc_count').textContent = documentsStore.length;
  if (!documentsStore.length) {
    wrap.innerHTML = '<div class="check-item">Nessun documento caricato. Trascina qui visura, DVR generale, screenshot Worklimate, planimetrie/foto e CSV lavoratori.</div>';
    return;
  }
  documentsStore.forEach((doc, index) => {
    const card = document.createElement('div');
    card.className = 'doc-card';
    const icon = document.createElement('div');
    icon.className = 'doc-icon';
    icon.textContent = docIcon(doc);
    const main = document.createElement('div');
    main.innerHTML = `<h4>${escapeHtml(doc.filename)}</h4><p>${formatBytes(doc.size_bytes)} · ${escapeHtml(doc.mime_type || 'tipo non noto')} ${doc.data_url ? '· immagine incorporata' : ''}</p>`;
    const select = document.createElement('select');
    DOC_CATEGORIES.forEach(([value, label]) => {
      const opt = document.createElement('option'); opt.value = value; opt.textContent = label; opt.selected = doc.category === value; select.appendChild(opt);
    });
    select.addEventListener('change', () => { doc.category = select.value; saveLocalDraft(false); });
    const desc = document.createElement('input');
    desc.value = doc.description || '';
    desc.placeholder = 'descrizione';
    desc.addEventListener('input', debounce(() => { doc.description = desc.value; saveLocalDraft(false); }, 200));
    const del = document.createElement('button');
    del.className = 'ghost danger';
    del.textContent = 'Rimuovi';
    del.addEventListener('click', () => { documentsStore.splice(index, 1); renderDocuments(); saveLocalDraft(false); refreshUI(); });
    card.append(icon, main, select, desc, del);
    wrap.appendChild(card);
  });
}

async function extractVisura() {
  if (!visuraFile) {
    toast('Carica prima una visura PDF/TXT.');
    return;
  }
  $('visura_status').textContent = 'Estrazione dati in corso...';
  const fd = new FormData();
  fd.append('file', visuraFile);
  try {
    const res = await fetch(`${API}/api/visura/extract`, { method: 'POST', body: fd });
    if (!res.ok) throw new Error(await res.text());
    const data = await res.json();
    const c = data.company || {};
    Object.entries({
      ragione_sociale: c.ragione_sociale,
      partita_iva: c.partita_iva,
      codice_fiscale: c.codice_fiscale,
      rea: c.rea,
      sede_legale: c.sede_legale,
      ateco: c.ateco,
      attivita: c.attivita,
    }).forEach(([id, val]) => { if (val && !value(id)) setValue(id, val); });
    const doc = documentsStore.find(d => d.filename === visuraFile.name);
    if (doc) doc.extracted_text_preview = data.text_preview || doc.extracted_text_preview;
    $('visura_status').textContent = 'Estrazione completata. Verifica e correggi i campi prima del DVR.';
    renderDocuments();
    refreshUI();
    saveLocalDraft(false);
  } catch (err) {
    $('visura_status').textContent = `Estrazione non riuscita: ${err.message}`;
  }
}

function companyPayload() {
  return {
    ragione_sociale: value('ragione_sociale') || 'AZIENDA DA COMPLETARE',
    partita_iva: value('partita_iva') || null,
    codice_fiscale: value('codice_fiscale') || null,
    rea: value('rea') || null,
    sede_legale: value('sede_legale') || null,
    sede_operativa: value('sede_operativa') || null,
    ateco: value('ateco') || null,
    attivita: value('attivita') || null,
    datore_lavoro: value('datore_lavoro') || null,
    rspp: value('rspp') || null,
    medico_competente: value('medico_competente') || null,
    rls: value('rls') || null,
    preposto: value('preposto') || null,
    referente_operativo: value('referente_operativo') || null,
    email_referente: value('email_referente') || null,
  };
}

function sitePayload() {
  return {
    nome: value('site_nome') || 'Sito non nominato',
    comune: value('site_comune') || null,
    provincia: value('site_provincia') || null,
    regione: value('site_regione') || 'Lombardia',
    indirizzo: value('site_indirizzo') || null,
    lat: num('site_lat'),
    lon: num('site_lon'),
    settore: value('site_settore') || 'edilizia_outdoor',
    esposizione_prolungata_sole: checked('site_sole'),
    pubblica_utilita_o_emergenza: checked('site_pubblica'),
    ombra_disponibile: checked('site_ombra'),
    area_fresca_o_climatizzata: checked('site_area_fresca'),
    acqua_disponibile: checked('site_acqua'),
    pause_programmate: checked('site_pause'),
    rotazione_addetti: checked('site_rotazione'),
    termoigrometro_disponibile: checked('site_termo'),
    temperatura_c: num('site_temp'),
    umidita_relativa: num('site_rh'),
    tnw_c: num('site_tnw'),
    tg_c: num('site_tg'),
    wbgt_outdoor_formula: true,
    note: value('site_note') || null,
  };
}

function dvrPayload() {
  return {
    company: companyPayload(),
    sites: [sitePayload()],
    employees,
    worklimate_results: worklimateResults,
    documents: documentsStore,
    assessment_date: assessmentDateForPayload(),
    prepared_by: value('prepared_by') || 'Safe 4 U Evolution S.r.l.',
    version: value('version') || '3.0',
    status: value('status') || 'bozza',
    include_employee_names: checked('include_names'),
    methodology_notes: value('methodology_notes') || null,
    conclusions_notes: value('conclusions_notes') || null,
    alert_settings: alertSettingsPayload(),
    alert_plan: alertPlan,
  };
}

function assessmentDateForPayload() {
  const manual = currentManualResultDate();
  return manual || new Date().toISOString().slice(0, 10);
}

function currentManualResultDate() {
  const wr = currentWorklimateResult();
  return wr?.days?.[0]?.day_key || null;
}

function getPhonePosition() {
  if (!navigator.geolocation) {
    toast('Geolocalizzazione non supportata. Inserisci indirizzo/coordinate manualmente.');
    return;
  }
  toast('Acquisizione posizione GPS...');
  navigator.geolocation.getCurrentPosition(
    pos => {
      setValue('site_lat', pos.coords.latitude.toFixed(6));
      setValue('site_lon', pos.coords.longitude.toFixed(6));
      toast(`Posizione acquisita, precisione ${Math.round(pos.coords.accuracy)} m`);
      refreshUI(); saveLocalDraft(false);
    },
    err => toast(`Errore GPS: ${err.message}`),
    { enableHighAccuracy: true, timeout: 15000, maximumAge: 300000 }
  );
}

async function fetchWorklimateRisk() {
  setRiskCards('Verifica...', 'n.d.', 'n.d.', 'n.d.');
  try {
    const res = await fetch(`${API}/api/worklimate/georisk`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ site: sitePayload(), search_radius_km: 100 })
    });
    if (!res.ok) throw new Error(await res.text());
    const data = await res.json();
    upsertWorklimate(data);
    renderRiskResult(data);
    await previewRisk(false);
  } catch (err) {
    toast(`Worklimate non disponibile: usa inserimento manuale. ${err.message}`);
    setRiskCards(currentRiskLabel(), 'n.d.', 'n.d.', 'Manuale richiesto');
  }
}

function applyManualRisk() {
  const label = value('manual_risk') || 'NON_DISPONIBILE';
  const site = sitePayload();
  const dayKey = new Date().toISOString().slice(0, 10);
  const data = {
    site_name: site.nome,
    pgrid: null,
    lat: site.lat,
    lon: site.lon,
    updated_at: new Date().toISOString(),
    days: [{
      day_key: dayKey,
      date_label: new Date().toLocaleDateString('it-IT') + ' ore 12:00',
      label,
      raw_label: label,
      description: 'Dato inserito manualmente dopo verifica portale Worklimate/registro.',
      long_description: null,
      source: 'Manuale operatore',
    }],
    raw: { manual: true },
    warning: 'Dato manuale: allegare screenshot/evidenza ufficiale nella sezione Documenti.'
  };
  upsertWorklimate(data);
  renderRiskResult(data);
  previewRisk(false);
}

function upsertWorklimate(data) {
  const siteName = data.site_name || sitePayload().nome;
  data.site_name = siteName;
  worklimateResults = worklimateResults.filter(x => (x.site_name || '').toLowerCase() !== siteName.toLowerCase());
  worklimateResults.push(data);
  saveLocalDraft(false);
}

function renderRiskResult(data) {
  const risk = maxRiskFromDays(data.days || []);
  previewRisk(false).then(() => refreshUI()).catch(() => refreshUI());
  setRiskCards(risk, lastPreview?.summary?.humidex ?? 'n.d.', lastPreview?.summary?.wbgt ?? 'n.d.', lastPreview?.legal_trigger?.divieto_1230_1600 ? 'STOP' : 'Non attivo');
}

function setRiskCards(risk, humidex, wbgt, ban) {
  $('risk_label_view').textContent = risk || 'NON DISPONIBILE';
  $('humidex_view').textContent = humidex === null || humidex === undefined ? 'n.d.' : humidex;
  $('wbgt_view').textContent = wbgt === null || wbgt === undefined ? 'n.d.' : wbgt;
  $('ban_view').textContent = ban || 'n.d.';
}

async function previewRisk(showToast = true) {
  const risk = currentRiskLabel();
  try {
    const res = await fetch(`${API}/api/rules/preview`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ site: sitePayload(), employees, risk_label: risk, reference_date: assessmentDateForPayload(), include_employee_names: checked('include_names') })
    });
    if (!res.ok) throw new Error(await res.text());
    lastPreview = await res.json();
    renderPreview(lastPreview);
    if (showToast) toast('Calcoli aggiornati.');
    saveLocalDraft(false);
    renderAlertPlan(buildAlertPlan(false));
    return lastPreview;
  } catch (err) {
    toast(`Errore calcolo: ${err.message}`);
    throw err;
  } finally {
    refreshUI();
  }
}

function renderPreview(data) {
  const calcs = data.calculations || [];
  const trigger = data.legal_trigger || {};
  setRiskCards(data.summary?.risk_label || currentRiskLabel(), data.summary?.humidex ?? 'n.d.', data.summary?.wbgt ?? 'n.d.', trigger.divieto_1230_1600 ? 'STOP 12:30-16:00' : 'Non attivo');
  const dashboard = $('calc_dashboard');
  dashboard.innerHTML = '';
  const cards = [
    ['Worklimate', data.summary?.risk_label || currentRiskLabel()],
    ['Humidex', data.summary?.humidex ?? 'n.d.'],
    ['WBGT', data.summary?.wbgt ?? 'n.d.'],
    ['Ordinanza', trigger.divieto_1230_1600 ? 'STOP 12:30-16:00' : (trigger.ordinanza_applicabile ? 'Applicabile, no stop' : 'Non applicabile')],
  ];
  cards.forEach(([title, text]) => {
    const div = document.createElement('div');
    div.className = 'calc-card';
    div.innerHTML = `<h3>${escapeHtml(title)}</h3><p>${escapeHtml(String(text))}</p>`;
    dashboard.appendChild(div);
  });
  const tbody = document.querySelector('#calc_table tbody');
  tbody.innerHTML = '';
  calcs.forEach(c => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${escapeHtml(c.employee_label)}</td><td>${escapeHtml(c.mansione)}</td><td>${c.initial_score}</td><td>${c.residual_score}</td><td><span class="pill ${classForRisk(c.risk_class)}">${c.risk_class}</span></td><td><span class="pill status-${c.operational_status}">${c.operational_status}</span></td><td>${c.resume_time || 'n.d.'}</td>`;
    tbody.appendChild(tr);
  });
}

async function dailyChecklist() {
  const risk = currentRiskLabel();
  try {
    const res = await fetch(`${API}/api/checklist/daily`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ site: sitePayload(), risk_label: risk, reference_date: assessmentDateForPayload() })
    });
    if (!res.ok) throw new Error(await res.text());
    const data = await res.json();
    const wrap = $('checklist_output');
    wrap.innerHTML = '';
    const decision = data.decision || {};
    const header = document.createElement('div');
    header.className = 'check-item';
    header.innerHTML = `<strong>Esito: ${escapeHtml(decision.status || 'n.d.')}</strong><br>Puoi lavorare ora: ${decision.can_work_now ? 'Sì' : 'No'} · Stop: ${decision.stop_window || 'n.d.'} · Ripresa: ${decision.resume_from || 'n.d.'}`;
    wrap.appendChild(header);
    (data.actions || []).forEach(action => {
      const div = document.createElement('div');
      div.className = 'check-item';
      div.textContent = action;
      wrap.appendChild(div);
    });
    toast('Checklist generata.');
  } catch (err) {
    toast(`Checklist non disponibile: ${err.message}`);
  }
}

function addEmployee() {
  const emp = employeeFromFields();
  if (!emp.id_lavoratore || !emp.mansione) { toast('Inserisci almeno ID/gruppo e mansione.'); return; }
  employees.push(emp);
  clearEmployeeFields();
  renderEmployees();
  refreshUI();
  saveLocalDraft(false);
}

function employeeFromFields() {
  return {
    id_lavoratore: value('emp_id') || `GR-${String(employees.length + 1).padStart(3, '0')}`,
    nome: value('emp_nome') || null,
    mansione: value('emp_mansione'),
    reparto: value('emp_reparto') || null,
    turno: value('emp_turno') || null,
    contratto: value('emp_contratto') || null,
    carico_fisico: value('emp_carico') || 'intensa',
    esposizione_sole: value('emp_sole') || 'prolungata',
    indoor_non_climatizzato: checked('emp_indoor'),
    dpi_indumenti_pesanti: checked('emp_dpi'),
    lavoro_solitario: checked('emp_solo'),
    neoassunto_o_non_acclimatato: checked('emp_acclimatato'),
    lavoratore_suscettibile: checked('emp_susc'),
    prescrizioni_medico_competente: value('emp_prescr') || null,
    note_attivita: value('emp_note') || null,
  };
}

function clearEmployeeFields() {
  ['emp_id','emp_nome','emp_mansione','emp_reparto','emp_turno','emp_contratto','emp_prescr','emp_note'].forEach(id => setValue(id, ''));
  setValue('emp_carico', 'intensa'); setValue('emp_sole', 'prolungata');
  ['emp_indoor','emp_dpi','emp_solo','emp_acclimatato','emp_susc'].forEach(id => setChecked(id, false));
}

function addDemoEmployees() {
  employees.push(
    { id_lavoratore: `GR-${String(employees.length + 1).padStart(3, '0')}`, nome: null, mansione: 'Muratori e addetti posa materiali', reparto: 'Squadra A', turno: '07:00-16:00', contratto: null, carico_fisico: 'intensa', esposizione_sole: 'prolungata', indoor_non_climatizzato: false, dpi_indumenti_pesanti: true, lavoro_solitario: false, neoassunto_o_non_acclimatato: false, lavoratore_suscettibile: false, prescrizioni_medico_competente: null, note_attivita: 'Movimentazione manuale e posa all’aperto.' },
    { id_lavoratore: `GR-${String(employees.length + 2).padStart(3, '0')}`, nome: null, mansione: 'Escavatorista / operatore macchina', reparto: 'Movimento terra', turno: '07:00-16:00', contratto: null, carico_fisico: 'moderata', esposizione_sole: 'frequente', indoor_non_climatizzato: false, dpi_indumenti_pesanti: false, lavoro_solitario: true, neoassunto_o_non_acclimatato: false, lavoratore_suscettibile: false, prescrizioni_medico_competente: null, note_attivita: 'Cabina non sempre climatizzata.' }
  );
  renderEmployees(); refreshUI(); saveLocalDraft(false); toast('Gruppi demo aggiunti.');
}

function renderEmployees() {
  const wrap = $('employee_cards');
  wrap.innerHTML = '';
  if (!employees.length) {
    wrap.innerHTML = '<div class="check-item">Nessun lavoratore/gruppo inserito. Importa CSV o aggiungi gruppi omogenei.</div>';
    return;
  }
  employees.forEach((emp, index) => {
    const factors = [];
    if (emp.carico_fisico === 'intensa') factors.push('sforzo intenso');
    if (emp.esposizione_sole !== 'assente') factors.push(`sole ${emp.esposizione_sole}`);
    if (emp.dpi_indumenti_pesanti) factors.push('DPI pesanti');
    if (emp.lavoro_solitario) factors.push('solo');
    if (emp.neoassunto_o_non_acclimatato) factors.push('non acclimatato');
    if (emp.lavoratore_suscettibile) factors.push('suscettibile');
    const card = document.createElement('div');
    card.className = 'emp-card';
    card.innerHTML = `<h3>${escapeHtml(emp.id_lavoratore)} · ${escapeHtml(emp.mansione)}</h3><p>${escapeHtml(emp.reparto || 'Reparto non indicato')} · ${escapeHtml(emp.turno || 'Turno n.d.')}</p><div class="tag-row">${factors.map(f => `<span class="tag">${escapeHtml(f)}</span>`).join('')}</div>`;
    const del = document.createElement('button');
    del.className = 'ghost danger'; del.textContent = 'Rimuovi';
    del.addEventListener('click', () => { employees.splice(index, 1); renderEmployees(); refreshUI(); saveLocalDraft(false); });
    card.appendChild(del);
    wrap.appendChild(card);
  });
}

async function generateDVR() {
  const payload = dvrPayload();
  $('debug').textContent = JSON.stringify({ ...payload, documents: payload.documents.map(d => ({ ...d, data_url: d.data_url ? '[immagine incorporata]' : null })) }, null, 2);
  try {
    const res = await fetch(`${API}/api/dvr/generate`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
    });
    if (!res.ok) throw new Error(await res.text());
    const blob = await res.blob();
    downloadBlob(blob, `DVR_Calore_${safeFileName(payload.company.ragione_sociale)}_${payload.assessment_date}.docx`);
    toast('DVR DOCX generato.');
  } catch (err) {
    toast(`Errore generazione DVR: ${err.message}`);
  }
}

function currentWorklimateResult() {
  const site = value('site_nome') || 'Sito non nominato';
  return worklimateResults.find(r => (r.site_name || '').toLowerCase() === site.toLowerCase()) || null;
}

function currentRiskLabel() {
  const res = currentWorklimateResult();
  if (!res || !res.days || !res.days.length) return 'NON_DISPONIBILE';
  return maxRiskFromDays(res.days);
}

function maxRiskFromDays(days) {
  return (days || []).map(d => d.label || 'NON_DISPONIBILE').sort((a, b) => (RISK_ORDER[b] || 0) - (RISK_ORDER[a] || 0))[0] || 'NON_DISPONIBILE';
}

function refreshUI() {
  const pct = completionScore();
  $('completion_pct').textContent = `${pct}%`;
  $('completion_bar').style.width = `${pct}%`;
  $('doc_count').textContent = documentsStore.length;
  const risk = currentRiskLabel();
  const chip = $('quick_risk');
  chip.textContent = risk;
  chip.className = `risk-chip ${risk === 'ALTO' ? 'risk-high' : risk === 'MODERATO' ? 'risk-mid' : risk === 'BASSO' ? 'risk-low' : 'risk-na'}`;
  const legalStop = lastPreview?.legal_trigger?.divieto_1230_1600;
  const decision = legalStop ? 'STOP operativo 12:30-16:00. Ripresa dalle 16:00 previa verifica.' : risk === 'ALTO' ? 'Misure rafforzate e registro giornaliero obbligatorio.' : risk === 'MODERATO' ? 'Lavoro con prescrizioni.' : risk === 'BASSO' ? 'Lavoro consentito con misure ordinarie.' : 'Dati insufficienti.';
  $('quick_decision').textContent = decision;
  $('hero_decision').textContent = legalStop ? 'STOP operativo' : (risk === 'NON_DISPONIBILE' ? 'In attesa dati' : `Rischio ${risk}`);
  updateNotificationStatus();
}

function completionScore() {
  const checks = [
    Boolean(value('ragione_sociale')),
    Boolean(value('partita_iva') || value('codice_fiscale')),
    Boolean(value('datore_lavoro')),
    Boolean(value('rspp')),
    documentsStore.some(d => d.category === 'visura_camerale'),
    documentsStore.some(d => d.category === 'screenshot_worklimate') || currentRiskLabel() !== 'NON_DISPONIBILE',
    Boolean(value('site_nome')),
    Boolean(value('site_comune') || (value('site_lat') && value('site_lon'))),
    employees.length > 0,
    currentRiskLabel() !== 'NON_DISPONIBILE',
    Boolean(lastPreview),
    Boolean(value('prepared_by')),
  ];
  return Math.round(checks.filter(Boolean).length / checks.length * 100);
}

function saveLocalDraft(show = false) {
  try {
    const raw = JSON.stringify({ payload: dvrPayload(), lastPreview });
    localStorage.setItem('SAFE4U_HEAT_DRAFT_V3', raw);
    if (show) toast('Bozza salvata localmente.');
  } catch (err) {
    if (show) toast('Bozza troppo grande per salvataggio locale. Esporta JSON.');
  }
}

function loadLocalDraft() {
  const raw = localStorage.getItem('SAFE4U_HEAT_DRAFT_V3');
  if (!raw) { renderDocuments(); renderEmployees(); return; }
  try {
    const data = JSON.parse(raw);
    if (data.payload) loadPayload(data.payload);
    lastPreview = data.lastPreview || null;
    if (lastPreview) renderPreview(lastPreview);
  } catch (_) { renderDocuments(); renderEmployees(); }
}

function loadPayload(payload) {
  const c = payload.company || {};
  Object.entries(c).forEach(([k, v]) => setValue(k, v));
  const s = (payload.sites || [])[0] || {};
  Object.entries({ site_nome: s.nome, site_comune: s.comune, site_provincia: s.provincia, site_regione: s.regione, site_indirizzo: s.indirizzo, site_lat: s.lat, site_lon: s.lon, site_settore: s.settore, site_temp: s.temperatura_c, site_rh: s.umidita_relativa, site_tnw: s.tnw_c, site_tg: s.tg_c, site_note: s.note }).forEach(([id, v]) => setValue(id, v));
  setChecked('site_sole', s.esposizione_prolungata_sole !== false);
  setChecked('site_pubblica', Boolean(s.pubblica_utilita_o_emergenza));
  setChecked('site_ombra', s.ombra_disponibile !== false);
  setChecked('site_area_fresca', Boolean(s.area_fresca_o_climatizzata));
  setChecked('site_acqua', s.acqua_disponibile !== false);
  setChecked('site_pause', s.pause_programmate !== false);
  setChecked('site_rotazione', Boolean(s.rotazione_addetti));
  setChecked('site_termo', Boolean(s.termoigrometro_disponibile));
  employees = payload.employees || [];
  documentsStore = payload.documents || [];
  worklimateResults = payload.worklimate_results || [];
  setValue('prepared_by', payload.prepared_by);
  setValue('version', payload.version || '3.0');
  setValue('status', payload.status || 'bozza');
  setValue('methodology_notes', payload.methodology_notes);
  setValue('conclusions_notes', payload.conclusions_notes);
  setChecked('include_names', Boolean(payload.include_employee_names));
  loadAlertSettings(payload.alert_settings || {});
  alertPlan = payload.alert_plan || [];
  renderDocuments(); renderEmployees(); refreshUI();
}

async function loadSample() {
  try {
    const res = await fetch(`${API}/api/sample`);
    if (!res.ok) throw new Error(await res.text());
    const payload = await res.json();
    loadPayload(payload);
    await previewRisk(false);
    toast('Demo caricata.');
  } catch (err) { toast(`Demo non caricabile: ${err.message}`); }
}

function clearAll() {
  if (!confirm('Azzerare tutta la pratica locale?')) return;
  localStorage.removeItem('SAFE4U_HEAT_DRAFT_V3');
  employees = []; documentsStore = []; worklimateResults = []; lastPreview = null; visuraFile = null;
  document.querySelectorAll('input, textarea').forEach(el => { if (el.type !== 'file' && el.id !== 'api_base') el.value = ''; });
  document.querySelectorAll('select').forEach(el => { if (el.id !== 'site_settore') el.selectedIndex = 0; });
  setValue('site_nome', 'Cantiere principale'); setValue('site_regione', 'Lombardia'); setValue('prepared_by', 'Safe 4 U Evolution S.r.l.'); setValue('version', '3.0');
  ['site_sole','site_ombra','site_acqua','site_pause','embed_images','alert_1030','alert_1200','alert_1220','alert_1230','alert_1600','alert_measures'].forEach(id => setChecked(id, true));
  ['site_pubblica','site_area_fresca','site_rotazione','site_termo','include_names','alert_enabled'].forEach(id => setChecked(id, false));
  setValue('alert_monitor_interval', '0'); setValue('alert_custom_time', '15:30'); setValue('alert_custom_text', ''); setValue('alert_mode', 'oggi'); setValue('alert_reference_date', new Date().toISOString().slice(0,10));
  alertPlan = []; cancelScheduledAlerts(false);
  setRiskCards('NON DISPONIBILE', 'n.d.', 'n.d.', 'n.d.'); renderDocuments(); renderEmployees(); renderPreview({ calculations: [], legal_trigger: {}, summary: {} }); initAlertsUI(); refreshUI();
}

function exportJSON() {
  downloadBlob(new Blob([JSON.stringify(dvrPayload(), null, 2)], { type: 'application/json' }), `safe4u_heat_dvr_${new Date().toISOString().slice(0,10)}.json`);
}

function importJSON(event) {
  const file = event.target.files[0]; if (!file) return;
  const reader = new FileReader();
  reader.onload = () => { try { loadPayload(JSON.parse(reader.result)); saveLocalDraft(false); toast('JSON importato.'); } catch (err) { toast(`JSON non valido: ${err.message}`); } };
  reader.readAsText(file);
}

function importCSVFromInput(event) {
  const file = event.target.files[0]; if (!file) return;
  readAsText(file).then(text => { importCSVText(text); addDocumentFromFile(file, 'elenco_lavoratori', 'CSV lavoratori importato'); });
}

function importCSVText(text) {
  const lines = text.split(/\r?\n/).filter(x => x.trim());
  if (!lines.length) return;
  const sep = lines[0].includes(';') ? ';' : ',';
  const headers = lines[0].split(sep).map(h => normalizeHeader(h));
  const hasHeader = headers.some(h => ['id_lavoratore','mansione','carico_fisico','esposizione_sole'].includes(h));
  const start = hasHeader ? 1 : 0;
  for (let i = start; i < lines.length; i++) {
    const cells = parseCSVLine(lines[i], sep);
    const get = (name, fallbackIndex = null) => {
      const idx = headers.indexOf(name);
      return idx >= 0 ? cells[idx] : (fallbackIndex !== null ? cells[fallbackIndex] : '');
    };
    const emp = {
      id_lavoratore: get('id_lavoratore', 0) || `CSV-${employees.length + 1}`,
      nome: get('nome') || null,
      mansione: get('mansione', 1) || 'Mansione da verificare',
      reparto: get('reparto') || null,
      turno: get('turno') || null,
      contratto: get('contratto') || null,
      carico_fisico: normalizeLoad(get('carico_fisico') || get('carico') || get('attivita_fisica')),
      esposizione_sole: normalizeSun(get('esposizione_sole') || get('sole') || get('esposizione')),
      indoor_non_climatizzato: boolText(get('indoor_non_climatizzato') || get('indoor')),
      dpi_indumenti_pesanti: boolText(get('dpi_indumenti_pesanti') || get('dpi')),
      lavoro_solitario: boolText(get('lavoro_solitario') || get('solo')),
      neoassunto_o_non_acclimatato: boolText(get('neoassunto_o_non_acclimatato') || get('non_acclimatato')),
      lavoratore_suscettibile: boolText(get('lavoratore_suscettibile') || get('suscettibile')),
      prescrizioni_medico_competente: get('prescrizioni') || null,
      note_attivita: get('note') || null,
    };
    employees.push(emp);
  }
  renderEmployees(); refreshUI(); saveLocalDraft(false); toast('Lavoratori importati da CSV.');
}


function initAlertsUI() {
  if ($('alert_reference_date') && !value('alert_reference_date')) setValue('alert_reference_date', new Date().toISOString().slice(0, 10));
  updateNotificationStatus();
  renderAlertPlan(buildAlertPlan(false));
}

function alertSettingsPayload() {
  if (!$('alert_enabled')) return {};
  return {
    enabled: checked('alert_enabled'),
    reference_date: value('alert_reference_date') || assessmentDateForPayload(),
    mode: value('alert_mode') || 'oggi',
    responsible: value('alert_responsabile') || value('preposto') || value('datore_lavoro') || null,
    escalation_channel: value('alert_escalation') || value('email_referente') || null,
    monitor_interval_minutes: Number(value('alert_monitor_interval') || 0),
    checkpoints: {
      precheck_1030: checked('alert_1030'),
      worklimate_1200: checked('alert_1200'),
      pre_stop_1220: checked('alert_1220'),
      stop_1230: checked('alert_1230'),
      resume_1600: checked('alert_1600'),
      measures: checked('alert_measures'),
    },
    custom: {
      time: value('alert_custom_time') || null,
      text: value('alert_custom_text') || null,
    },
  };
}

function loadAlertSettings(settings) {
  if (!$('alert_enabled')) return;
  setChecked('alert_enabled', Boolean(settings.enabled));
  setValue('alert_reference_date', settings.reference_date || new Date().toISOString().slice(0, 10));
  setValue('alert_mode', settings.mode || 'oggi');
  setValue('alert_responsabile', settings.responsible || '');
  setValue('alert_escalation', settings.escalation_channel || '');
  setValue('alert_monitor_interval', String(settings.monitor_interval_minutes ?? 0));
  const cp = settings.checkpoints || {};
  setChecked('alert_1030', cp.precheck_1030 !== false);
  setChecked('alert_1200', cp.worklimate_1200 !== false);
  setChecked('alert_1220', cp.pre_stop_1220 !== false);
  setChecked('alert_1230', cp.stop_1230 !== false);
  setChecked('alert_1600', cp.resume_1600 !== false);
  setChecked('alert_measures', cp.measures !== false);
  setValue('alert_custom_time', settings.custom?.time || '15:30');
  setValue('alert_custom_text', settings.custom?.text || '');
}

function updateNotificationStatus() {
  if (!$('notification_status')) return;
  const supported = 'Notification' in window;
  const permission = supported ? Notification.permission : 'unsupported';
  const enabled = checked('alert_enabled');
  let label = 'Non supportate';
  if (supported && permission === 'granted' && enabled) label = 'Attive su questo telefono';
  else if (supported && permission === 'granted') label = 'Permesso concesso, attiva switch';
  else if (supported && permission === 'denied') label = 'Bloccate dal browser';
  else if (supported) label = 'Da attivare';
  $('notification_status').textContent = label;
  $('notification_runtime').textContent = nativeNotificationRuntimeText();
}

function nativeNotificationRuntimeText() {
  const native = Boolean(window.Capacitor?.isNativePlatform?.());
  if (native) return 'Android: notifiche locali native persistenti.';
  return 'Web/PWA: notifiche locali disponibili con permesso, scheduling attivo mentre app aperta.';
}

async function requestNotificationPermission() {
  if (!('Notification' in window)) { toast('Questo browser non supporta le notifiche.'); updateNotificationStatus(); return false; }
  if (!('serviceWorker' in navigator) && location.protocol !== 'https:' && location.hostname !== 'localhost') {
    toast('Per notifiche PWA serve HTTPS o localhost.');
    return false;
  }
  const result = await Notification.requestPermission();
  setChecked('alert_enabled', result === 'granted');
  updateNotificationStatus();
  toast(result === 'granted' ? 'Notifiche attivate.' : 'Permesso notifiche non concesso.');
  saveLocalDraft(false);
  return result === 'granted';
}

async function showPhoneAlert(title, body, tag = 'safe4u-heat-alert') {
  if (!('Notification' in window)) { toast(`${title}: ${body}`); return false; }
  if (Notification.permission !== 'granted') {
    const ok = await requestNotificationPermission();
    if (!ok) return false;
  }
  const options = {
    body,
    icon: './assets/logo_square_512.png',
    badge: './favicon_32.png',
    tag,
    requireInteraction: true,
    data: { url: location.href, tag },
  };
  try {
    const reg = await navigator.serviceWorker?.getRegistration?.();
    if (reg?.showNotification) await reg.showNotification(title, options);
    else new Notification(title, options);
    return true;
  } catch (_) {
    new Notification(title, options);
    return true;
  }
}

async function testNotification() {
  const ok = await showPhoneAlert('Safe 4 U Heat Check', 'Test allert riuscito: il telefono riceverà avvisi su stop, ripresa e misure caldo.', 'safe4u-test');
  if (ok) toast('Notifica test inviata.');
}

function buildAlertPlan(save = true) {
  if (!$('alert_enabled')) return [];
  const settings = alertSettingsPayload();
  const refDate = settings.reference_date || new Date().toISOString().slice(0, 10);
  const risk = currentRiskLabel();
  const legalStop = Boolean(lastPreview?.legal_trigger?.divieto_1230_1600);
  const triggerMsg = lastPreview?.legal_trigger?.messaggio || '';
  const siteName = value('site_nome') || 'sito/cantiere';
  const sector = $('site_settore')?.selectedOptions?.[0]?.textContent || value('site_settore') || 'settore non indicato';
  const base = [];
  const push = (time, title, body, severity = 'info', mandatory = false) => {
    const item = buildAlertItem(refDate, time, title, body, severity, mandatory, settings.mode);
    base.push(item);
  };
  if (settings.checkpoints.precheck_1030) push('10:30', 'Pre-check rischio caldo', `Verifica misure prima della fascia critica: acqua, ombra, pause, rotazione e preposto su ${siteName}.`, 'info');
  if (settings.checkpoints.worklimate_1200) push('12:00', 'Verifica Worklimate ore 12:00', `Controlla rischio Worklimate per lavoratori esposti al sole con attività intensa. Rischio attuale app: ${risk}.`, risk === 'ALTO' ? 'warning' : 'info', true);
  if (settings.checkpoints.pre_stop_1220) push('12:20', legalStop ? 'Preavviso STOP 12:30' : 'Preavviso fascia critica', legalStop ? `Tra 10 minuti stop attività in esposizione prolungata al sole. Settore: ${sector}.` : 'Fascia critica in arrivo: conferma misure rafforzate e rivaluta attività pesanti.', legalStop ? 'danger' : 'warning');
  if (settings.checkpoints.stop_1230) push('12:30', legalStop ? 'STOP operativo attivo' : 'Controllo 12:30-16:00', legalStop ? 'Non svolgere attività in esposizione prolungata al sole. Rimodula o sospendi fino alle 16:00 salvo deroghe documentate.' : 'Conferma che acqua, ombra, pause e controllo preposto siano attivi durante la fascia calda.', legalStop ? 'danger' : 'warning', legalStop);
  if (settings.checkpoints.resume_1600) push('16:00', 'Check ripresa lavoro', legalStop ? 'Ripresa possibile solo previa nuova verifica: condizioni lavoratori, misure rafforzate e registro giornaliero.' : 'Esegui controllo finale e registra eventuali misure applicate.', legalStop ? 'warning' : 'info');
  if (settings.checkpoints.measures && risk === 'ALTO') push('14:00', 'Monitoraggio misure caldo', 'Conferma acqua fresca, pause effettive, ombra/area recupero e assenza di lavoro isolato.', 'warning');
  if (settings.custom.time && settings.custom.text) push(settings.custom.time, 'Allert personalizzato Safe 4 U', settings.custom.text, 'info');
  const interval = Number(settings.monitor_interval_minutes || 0);
  if (interval > 0 && (risk === 'ALTO' || legalStop)) {
    const start = 9 * 60;
    const end = 17 * 60;
    for (let m = start; m <= end; m += interval) {
      const hh = String(Math.floor(m / 60)).padStart(2, '0');
      const mm = String(m % 60).padStart(2, '0');
      const time = `${hh}:${mm}`;
      if (['10:30','12:00','12:20','12:30','14:00','16:00'].includes(time)) continue;
      push(time, 'Monitoraggio programmato rischio caldo', 'Esegui controllo rapido su idratazione, pause, ombra, sintomi e rimodulazione attività.', 'warning');
    }
  }
  const dedup = new Map();
  base.sort((a,b) => a.time.localeCompare(b.time)).forEach(item => dedup.set(`${item.date}_${item.time}_${item.title}`, item));
  alertPlan = Array.from(dedup.values());
  if ($('alert_decision')) {
    const status = legalStop ? 'ROSSO - STOP 12:30-16:00' : risk === 'ALTO' ? 'GIALLO/ROSSO operativo - misure rafforzate' : risk === 'MODERATO' ? 'GIALLO - monitoraggio' : risk === 'BASSO' ? 'VERDE - misure ordinarie' : 'GRIGIO - dati insufficienti';
    $('alert_decision').innerHTML = `<strong>${escapeHtml(status)}</strong><br>${escapeHtml(triggerMsg || 'Genera o aggiorna i calcoli per motivare le allerte.')}`;
  }
  if (save) saveLocalDraft(false);
  return alertPlan;
}

function buildAlertItem(refDate, time, title, body, severity, mandatory, mode) {
  const scheduled = dateTimeForLocal(refDate, time);
  const now = new Date();
  let scheduledAt = scheduled;
  let status = scheduledAt.getTime() > now.getTime() ? 'programmabile' : 'passato';
  if (mode === 'giornaliera' && scheduledAt.getTime() <= now.getTime()) {
    scheduledAt = new Date(scheduledAt.getTime() + 24 * 60 * 60 * 1000);
    status = 'prossimo giorno';
  }
  const delay = scheduledAt.getTime() - now.getTime();
  const maxDelay = 2147483647;
  const canSchedule = delay > 0 && delay <= maxDelay;
  return {
    id: `alert-${refDate}-${time}-${slugify(title)}`,
    date: refDate,
    time,
    scheduled_at: scheduledAt.toISOString(),
    delay_ms: Math.max(0, delay),
    can_schedule: canSchedule,
    status: canSchedule ? status : (delay <= 0 ? 'passato' : 'troppo distante'),
    title,
    body,
    severity,
    mandatory,
  };
}

function dateTimeForLocal(dateKey, time) {
  const [hh, mm] = String(time || '00:00').split(':').map(Number);
  const [yyyy, mo, dd] = String(dateKey || new Date().toISOString().slice(0,10)).split('-').map(Number);
  return new Date(yyyy, (mo || 1) - 1, dd || 1, hh || 0, mm || 0, 0, 0);
}

function renderAlertPlan(plan = alertPlan) {
  if (!$('alert_plan')) return;
  const wrap = $('alert_plan');
  wrap.innerHTML = '';
  updateNotificationStatus();
  if (!plan || !plan.length) {
    wrap.innerHTML = '<div class="check-item">Nessun allert generato. Premi “Genera piano allerte” dopo aver calcolato il rischio.</div>';
    return;
  }
  plan.forEach(item => {
    const div = document.createElement('div');
    div.className = `alert-item severity-${item.severity}`;
    div.innerHTML = `<div><span>${escapeHtml(item.date)} · ${escapeHtml(item.time)}</span><h3>${escapeHtml(item.title)}</h3><p>${escapeHtml(item.body)}</p></div><strong>${escapeHtml(item.status)}</strong>`;
    wrap.appendChild(div);
  });
}

async function schedulePhoneAlerts() {
  if (!checked('alert_enabled')) setChecked('alert_enabled', true);
  if (!('Notification' in window)) { toast('Notifiche non supportate su questo dispositivo/browser.'); return; }
  if (Notification.permission !== 'granted') {
    const ok = await requestNotificationPermission();
    if (!ok) return;
  }
  cancelScheduledAlerts(false);
  const plan = buildAlertPlan(true);
  renderAlertPlan(plan);
  let count = 0;
  for (const item of plan) {
    if (!item.can_schedule) continue;
    const timer = setTimeout(() => showPhoneAlert(item.title, item.body, item.id), item.delay_ms);
    alertTimers.push(timer);
    count += 1;
  }
  toast(count ? `${count} allert programmati su questo telefono.` : 'Nessun allert futuro programmabile oggi.');
}

function cancelScheduledAlerts(show = true) {
  alertTimers.forEach(t => clearTimeout(t));
  alertTimers = [];
  if (show) toast('Allert locali annullati.');
}

function slugify(s) { return String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 64); }

function openHelp(key) {
  const content = HELP[key] || HELP.generale;
  $('help_title').textContent = content.title;
  $('help_body').innerHTML = content.body;
  $('help_dialog').showModal();
}

function currentHelpKey() { return ['azienda','documenti','sito','lavoratori','calcoli','allerte','genera'][currentStep] || 'generale'; }

const HELP = {
  generale: { title: 'Guida rapida', body: '<ol><li>Carica visura e documenti in drag & drop.</li><li>Compila sito e geolocalizzazione.</li><li>Inserisci Worklimate automatico o manuale.</li><li>Inserisci lavoratori/gruppi omogenei.</li><li>Aggiorna calcoli e genera il DVR.</li></ol>' },
  azienda: { title: 'Come compilare Azienda', body: '<h3>Dati obbligatori</h3><p>Inserisci ragione sociale, P.IVA/C.F., sede, Datore di Lavoro, RSPP, Medico Competente se nominato, RLS/RLST e preposto. La visura può precompilare i dati ma devi validarli.</p><h3>Errore da evitare</h3><p>Non generare il DVR con intestazione incompleta o non coerente con la visura camerale.</p>' },
  documenti: { title: 'Come usare il drag & drop documenti', body: '<h3>Visura</h3><p>Trascina la visura nel box sinistro, poi premi “Estrai dati da visura”.</p><h3>Altri documenti</h3><p>Nel box destro carica DVR generale, POS/PSC, elenco lavoratori CSV, screenshot Worklimate, planimetrie, foto di ombra/acqua/pause e nomine. Ogni file viene registrato nel DVR. Le immagini possono essere incorporate nel documento finale.</p><h3>CSV lavoratori</h3><p>Colonne consigliate: id_lavoratore, mansione, reparto, turno, carico_fisico, esposizione_sole, dpi, lavoro_solitario, non_acclimatato, suscettibile, prescrizioni.</p>' },
  sito: { title: 'Come compilare Sito & Worklimate', body: '<p>Usa il GPS del telefono o inserisci coordinate/indirizzo. Seleziona settore, regione, esposizione al sole, misure presenti e dati locali. Il rischio Worklimate può essere acquisito automaticamente o inserito manualmente dopo verifica sul portale ufficiale, allegando screenshot.</p><p>Per Lombardia il trigger opera su periodo, settore, esposizione prolungata al sole e rischio ALTO.</p>' },
  lavoratori: { title: 'Come compilare Lavoratori', body: '<p>Usa gruppi omogenei o codici interni. I nomi sono facoltativi e vanno evitati nella copia esterna salvo necessità. Non inserire diagnosi, farmaci o patologie: usa solo il flag “suscettibile” e prescrizioni operative del Medico Competente.</p>' },
  calcoli: { title: 'Come leggere i calcoli', body: '<p>L’indice operativo usa R = P x D x C, poi riduce il rischio residuo in base alle misure presenti. Lo score è uno strumento aziendale, non un indice di legge. Il semaforo indica: verde lavoro consentito, giallo misure rafforzate, rosso stop/rimodulazione.</p>' },
  allerte: { title: 'Come compilare le allerte telefono', body: '<h3>Obiettivo</h3><p>Attiva gli allert sul cellulare del datore/preposto/operatore per non dimenticare verifica Worklimate, stop 12:30, misure e ripresa 16:00.</p><h3>Come fare</h3><ol><li>Premi “Attiva permesso notifiche”.</li><li>Seleziona gli orari di controllo.</li><li>Compila responsabile ed eventuale canale escalation.</li><li>Premi “Genera piano allerte”.</li><li>Premi “Programma allert sul telefono”.</li></ol><h3>Errore da evitare</h3><p>Non usare gli allert come sostituto della valutazione: servono a ricordare cosa fare, mentre la decisione nasce da Worklimate, ordinanza, DVR e misure effettive.</p>' },
  genera: { title: 'Generazione DVR', body: '<p>Prima di generare verifica completamento, documenti, Worklimate, lavoratori, calcoli e note. Il DOCX generato contiene logo Safe 4 U, copertina, indice, grafici, tabelle, misure, registro e firme.</p>' },
};

function guessCategory(name, type) {
  const n = name.toLowerCase();
  if (n.includes('visura')) return 'visura_camerale';
  if (n.includes('worklimate') || n.includes('screenshot')) return 'screenshot_worklimate';
  if (n.includes('lavorator') || n.endsWith('.csv') || n.includes('dipendent')) return 'elenco_lavoratori';
  if (n.includes('planimetr') || n.includes('layout') || n.includes('mappa')) return 'planimetria_o_layout';
  if (n.includes('dvr')) return 'dvr_generale';
  if (n.includes('ordinanza')) return 'ordinanza';
  if (n.includes('nomina') || n.includes('rspp') || n.includes('rls')) return 'nomine_sicurezza';
  if (type && type.startsWith('image/')) return 'foto_misure';
  return 'altro';
}
function docIcon(doc) { if ((doc.mime_type || '').startsWith('image/')) return 'IMG'; if ((doc.mime_type || '').includes('pdf')) return 'PDF'; if (doc.filename.toLowerCase().endsWith('.csv')) return 'CSV'; return 'DOC'; }
function mimeFromName(name) { const n = name.toLowerCase(); if (n.endsWith('.pdf')) return 'application/pdf'; if (n.endsWith('.csv')) return 'text/csv'; if (n.endsWith('.txt')) return 'text/plain'; if (n.endsWith('.png')) return 'image/png'; if (n.endsWith('.jpg') || n.endsWith('.jpeg')) return 'image/jpeg'; return 'application/octet-stream'; }
function readAsDataURL(file) { return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(file); }); }
function readAsText(file) { return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsText(file); }); }
function formatBytes(v) { if (!v) return '0 B'; if (v < 1024) return `${v} B`; if (v < 1024**2) return `${(v/1024).toFixed(1)} KB`; return `${(v/1024**2).toFixed(1)} MB`; }
function escapeHtml(s) { return String(s ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }
function safeFileName(s) { return String(s || 'azienda').replace(/[^a-z0-9]+/gi, '_').replace(/^_+|_+$/g, ''); }
function downloadBlob(blob, filename) { const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url); }
function debounce(fn, delay = 250) { let t; return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), delay); }; }
function toast(text) { const t = $('toast'); t.textContent = text; t.classList.add('show'); clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.remove('show'), 3200); }
function classForRisk(r) { return r === 'MOLTO_ALTO' ? 'status-ROSSO' : r === 'ALTO' ? 'status-GIALLO' : r === 'MEDIO' ? 'status-GIALLO' : 'status-VERDE'; }
function parseCSVLine(line, sep) { const out=[]; let cur='', q=false; for (let i=0;i<line.length;i++){ const ch=line[i]; if(ch==='"'){ q=!q; continue; } if(ch===sep && !q){ out.push(cur.trim()); cur=''; } else cur+=ch; } out.push(cur.trim()); return out; }
function normalizeHeader(h) { return String(h || '').trim().toLowerCase().replace(/[\s\-]+/g, '_').replace(/[^a-z0-9_]/g, ''); }
function normalizeLoad(v) { v = String(v || '').toLowerCase(); if (v.includes('legg')) return 'leggera'; if (v.includes('mod') || v.includes('med')) return 'moderata'; return 'intensa'; }
function normalizeSun(v) { v = String(v || '').toLowerCase(); if (v.includes('ass') || v === 'no') return 'assente'; if (v.includes('occ')) return 'occasionale'; if (v.includes('freq')) return 'frequente'; return 'prolungata'; }
function boolText(v) { return ['1','si','sì','true','x','yes','y'].includes(String(v || '').trim().toLowerCase()); }

if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
  navigator.serviceWorker.register('./service-worker.js').catch(() => {});
}

document.addEventListener('DOMContentLoaded', init);

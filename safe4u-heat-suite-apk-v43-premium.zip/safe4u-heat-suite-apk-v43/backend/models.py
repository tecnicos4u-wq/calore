from __future__ import annotations

from datetime import date, datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, field_validator, model_validator


class Sector(str, Enum):
    agricoltura = "agricoltura"
    florovivaismo = "florovivaismo"
    edilizia_outdoor = "edilizia_outdoor"
    cave = "cave"
    logistica_piazzali = "logistica_piazzali"
    indoor_non_climatizzato = "indoor_non_climatizzato"
    manutenzioni_esterne = "manutenzioni_esterne"
    altro = "altro"


class RiskLabel(str, Enum):
    non_disponibile = "NON_DISPONIBILE"
    basso = "BASSO"
    moderato = "MODERATO"
    alto = "ALTO"


class RiskClass(str, Enum):
    basso = "BASSO"
    medio = "MEDIO"
    alto = "ALTO"
    molto_alto = "MOLTO_ALTO"


class OperationalStatus(str, Enum):
    verde = "VERDE"
    giallo = "GIALLO"
    rosso = "ROSSO"
    grigio = "GRIGIO"


class PhysicalLoad(str, Enum):
    leggera = "leggera"
    moderata = "moderata"
    intensa = "intensa"


class SunExposure(str, Enum):
    assente = "assente"
    occasionale = "occasionale"
    frequente = "frequente"
    prolungata = "prolungata"


class DocumentStatus(str, Enum):
    bozza = "bozza"
    validato = "validato"
    firmato = "firmato"


class AttachmentCategory(str, Enum):
    visura = "visura_camerale"
    dvr_generale = "dvr_generale"
    ordinanza = "ordinanza"
    worklimate = "screenshot_worklimate"
    lavoratori = "elenco_lavoratori"
    planimetria = "planimetria_o_layout"
    foto_misure = "foto_misure"
    nomine = "nomine_sicurezza"
    procedura = "procedure"
    altro = "altro"


class Company(BaseModel):
    ragione_sociale: str = Field(..., min_length=1)
    partita_iva: Optional[str] = None
    codice_fiscale: Optional[str] = None
    rea: Optional[str] = None
    sede_legale: Optional[str] = None
    sede_operativa: Optional[str] = None
    ateco: Optional[str] = None
    attivita: Optional[str] = None
    datore_lavoro: Optional[str] = None
    rspp: Optional[str] = None
    medico_competente: Optional[str] = None
    rls: Optional[str] = None
    preposto: Optional[str] = None
    referente_operativo: Optional[str] = None
    email_referente: Optional[str] = None


class Employee(BaseModel):
    id_lavoratore: str = Field(..., description="Codice interno/pseudonimo. Evitare dati sanitari nel DVR.")
    nome: Optional[str] = Field(None, description="Facoltativo: usare solo se necessario nella copia interna autorizzata.")
    mansione: str
    reparto: Optional[str] = None
    turno: Optional[str] = None
    contratto: Optional[str] = None
    carico_fisico: PhysicalLoad = PhysicalLoad.intensa
    esposizione_sole: SunExposure = SunExposure.prolungata
    indoor_non_climatizzato: bool = False
    dpi_indumenti_pesanti: bool = False
    lavoro_solitario: bool = False
    neoassunto_o_non_acclimatato: bool = False
    lavoratore_suscettibile: bool = Field(False, description="Solo flag operativo. Non inserire patologie, diagnosi o farmaci.")
    prescrizioni_medico_competente: Optional[str] = Field(None, description="Solo indicazioni operative; no diagnosi.")
    note_attivita: Optional[str] = None


class Site(BaseModel):
    nome: str
    comune: Optional[str] = None
    provincia: Optional[str] = None
    regione: str = "Lombardia"
    indirizzo: Optional[str] = None
    lat: Optional[float] = None
    lon: Optional[float] = None
    settore: Sector = Sector.edilizia_outdoor
    esposizione_prolungata_sole: bool = True
    pubblica_utilita_o_emergenza: bool = False
    ombra_disponibile: bool = True
    area_fresca_o_climatizzata: bool = False
    acqua_disponibile: bool = True
    pause_programmate: bool = True
    rotazione_addetti: bool = False
    termoigrometro_disponibile: bool = False
    temperatura_c: Optional[float] = Field(None, description="Temperatura aria locale, se disponibile")
    umidita_relativa: Optional[float] = Field(None, description="Umidità relativa %, se disponibile")
    tnw_c: Optional[float] = Field(None, description="Temperatura bulbo umido naturale, se misurata per WBGT")
    tg_c: Optional[float] = Field(None, description="Temperatura globotermometro, se misurata per WBGT")
    wbgt_outdoor_formula: bool = True
    note: Optional[str] = None

    @field_validator("lat")
    @classmethod
    def validate_lat(cls, v: Optional[float]) -> Optional[float]:
        if v is not None and not (-90 <= v <= 90):
            raise ValueError("latitudine fuori range")
        return v

    @field_validator("lon")
    @classmethod
    def validate_lon(cls, v: Optional[float]) -> Optional[float]:
        if v is not None and not (-180 <= v <= 180):
            raise ValueError("longitudine fuori range")
        return v

    @field_validator("umidita_relativa")
    @classmethod
    def validate_rh(cls, v: Optional[float]) -> Optional[float]:
        if v is not None and not (0 <= v <= 100):
            raise ValueError("umidità relativa fuori range 0-100")
        return v


class WorklimateDay(BaseModel):
    day_key: str
    date_label: Optional[str] = None
    label: RiskLabel
    raw_label: Optional[str] = None
    description: Optional[str] = None
    long_description: Optional[str] = None
    source: str = "Worklimate"


class WorklimateResult(BaseModel):
    site_name: Optional[str] = None
    pgrid: Optional[int] = None
    lat: Optional[float] = None
    lon: Optional[float] = None
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    days: List[WorklimateDay] = Field(default_factory=list)
    raw: Optional[Dict[str, Any]] = None
    warning: Optional[str] = None


class DocumentAttachment(BaseModel):
    id: str
    filename: str
    category: AttachmentCategory = AttachmentCategory.altro
    mime_type: Optional[str] = None
    size_bytes: Optional[int] = None
    description: Optional[str] = None
    data_url: Optional[str] = Field(None, description="Facoltativo: usato per incorporare immagini nel DVR; evitare file grandi.")
    extracted_text_preview: Optional[str] = None
    uploaded_at: datetime = Field(default_factory=datetime.utcnow)

    @field_validator("size_bytes")
    @classmethod
    def validate_size(cls, v: Optional[int]) -> Optional[int]:
        if v is not None and v < 0:
            raise ValueError("dimensione file non valida")
        return v


class CalculationComponent(BaseModel):
    voce: str
    valore: str
    punteggio: float
    nota: Optional[str] = None


class WorkerCalculation(BaseModel):
    employee_id: str
    employee_label: str
    mansione: str
    site_name: str
    worklimate_label: RiskLabel
    probability: int
    damage: int
    aggravating_coefficient: float
    initial_score: float
    mitigation_credit: float
    residual_score: float
    risk_class: RiskClass
    operational_status: OperationalStatus
    legal_ban: bool
    components: List[CalculationComponent]
    humidex: Optional[float] = None
    wbgt: Optional[float] = None
    recommended_actions: List[str]
    resume_time: Optional[str] = None


class LegalTriggerResult(BaseModel):
    ordinanza_applicabile: bool
    rischio_alto: bool
    esclusione_pubblica_utilita: bool
    divieto_1230_1600: bool
    fascia_divieto: Optional[str]
    messaggio: str
    legal_basis: List[str] = Field(default_factory=list)


class DVRInput(BaseModel):
    company: Company
    employees: List[Employee] = Field(default_factory=list)
    sites: List[Site] = Field(default_factory=list)
    worklimate_results: List[WorklimateResult] = Field(default_factory=list)
    attachments: List[DocumentAttachment] = Field(default_factory=list, description="Metadati dei documenti caricati con drag and drop e allegati alla pratica.")
    documents: List[DocumentAttachment] = Field(default_factory=list)
    assessment_date: date = Field(default_factory=date.today)
    prepared_by: Optional[str] = None
    version: str = "3.0"
    status: DocumentStatus = DocumentStatus.bozza
    include_employee_names: bool = False
    methodology_notes: Optional[str] = None
    conclusions_notes: Optional[str] = None
    alert_settings: Dict[str, Any] = Field(default_factory=dict, description="Configurazione allert smartphone per app operativa.")
    alert_plan: List[Dict[str, Any]] = Field(default_factory=list, description="Piano allerte generato dall’app per datore/preposto/operatore.")

    @model_validator(mode="after")
    def normalize_and_validate(self) -> "DVRInput":
        # Compatibilità tra frontend storico (documents) e API nuova (attachments).
        # Il DVR usa `documents`; le integrazioni enterprise possono inviare `attachments`.
        if not self.documents and self.attachments:
            self.documents = list(self.attachments)
        if not self.attachments and self.documents:
            self.attachments = list(self.documents)
        if not self.sites:
            raise ValueError("Inserire almeno un sito/cantiere")
        return self


class GeoRiskRequest(BaseModel):
    site: Site
    search_radius_km: int = 100


class DailyChecklistRequest(BaseModel):
    site: Site
    risk_label: RiskLabel
    reference_date: date = Field(default_factory=date.today)


class PreviewRequest(BaseModel):
    company: Optional[Company] = None
    employees: List[Employee] = Field(default_factory=list)
    site: Site
    risk_label: RiskLabel = RiskLabel.non_disponibile
    reference_date: date = Field(default_factory=date.today)
    include_employee_names: bool = False

from __future__ import annotations

import json
import os
from datetime import date
from typing import List
from uuid import uuid4

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
from pydantic import ValidationError

from dvr_builder import generate_dvr_docx
from models import DailyChecklistRequest, DocumentAttachment, DVRInput, GeoRiskRequest, PreviewRequest, RiskLabel, WorklimateResult
from rules import calculations_for_site, legal_trigger, operational_summary
from visura_extractor import extract_company_from_upload
from worklimate_client import WorklimateClient

APP_VERSION = "3.1-safe4u-alerts"

app = FastAPI(
    title="Safe 4 U Heat DVR API",
    version=APP_VERSION,
    description="Generatore DVR calore con drag & drop documenti, Worklimate, calcoli, grafici, checklist operativa e allert smartphone.",
)

origins = [o.strip() for o in os.getenv("CORS_ORIGINS", "http://localhost:8080,http://127.0.0.1:8080,http://localhost:5173").split(",")]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins + ["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

client = WorklimateClient()


@app.get("/api/health")
def health() -> dict:
    return {"status": "ok", "version": APP_VERSION}


@app.post("/api/visura/extract")
async def extract_visura(file: UploadFile = File(...)) -> dict:
    content = await file.read()
    if not content:
        raise HTTPException(status_code=400, detail="File vuoto")
    try:
        return extract_company_from_upload(file.filename or "visura", content)
    except Exception as exc:
        raise HTTPException(status_code=422, detail=f"Estrazione non riuscita: {exc}") from exc


def _preview_text(filename: str, content: bytes, content_type: str | None = None) -> str | None:
    lower = filename.lower()
    try:
        if lower.endswith((".txt", ".csv", ".json", ".md")) or (content_type and "text" in content_type):
            return content[:4000].decode("utf-8", errors="ignore").strip()[:1200]
        if lower.endswith(".pdf"):
            from io import BytesIO
            from pypdf import PdfReader
            reader = PdfReader(BytesIO(content))
            text = "\n".join((page.extract_text() or "") for page in reader.pages[:3])
            return text.strip()[:1200] if text else None
    except Exception:
        return None
    return None


@app.post("/api/documents/ingest")
async def ingest_documents(files: List[UploadFile] = File(...), category: str = "altro") -> dict:
    """Ingestione documenti via drag and drop.

    MVP: restituisce metadati e anteprima testuale; in produzione i file vanno
    salvati su storage cifrato, collegati alla pratica e sottoposti a retention policy.
    """
    category_map = {
        "visura": "visura_camerale",
        "worklimate": "screenshot_worklimate",
        "foto_area": "foto_misure",
        "misure": "procedure",
        "planimetria": "planimetria_o_layout",
        "allegato": "altro",
    }
    normalized_category = category_map.get(category, category)
    documents: List[DocumentAttachment] = []
    extracted_company = None
    for file in files:
        content = await file.read()
        if not content:
            continue
        preview = _preview_text(file.filename or "documento", content, file.content_type)
        doc = DocumentAttachment(
            id=str(uuid4()),
            filename=file.filename or "documento",
            category=normalized_category,
            mime_type=file.content_type,
            size_bytes=len(content),
            description="Caricato tramite area drag and drop",
            extracted_text_preview=preview,
        )
        documents.append(doc)
        if normalized_category == "visura_camerale" or "visura" in (file.filename or "").lower():
            try:
                extracted_company = extract_company_from_upload(file.filename or "visura", content)
            except Exception:
                extracted_company = None
    return {
        "documents": [d.model_dump(mode="json") for d in documents],
        "extracted_company": extracted_company,
        "warning": "MVP: metadati restituiti al client; storage persistente/cifrato da collegare in fase enterprise.",
    }


@app.post("/api/worklimate/georisk", response_model=WorklimateResult)
def georisk(request: GeoRiskRequest) -> WorklimateResult:
    return client.georisk(request)


@app.post("/api/rules/preview")
def preview(request: PreviewRequest) -> dict:
    calcs = calculations_for_site(
        request.employees,
        request.site,
        request.risk_label,
        request.reference_date,
        include_names=request.include_employee_names,
    )
    trigger = legal_trigger(request.site, request.risk_label, request.reference_date)
    return {
        "legal_trigger": trigger.model_dump(),
        "calculations": [c.model_dump() for c in calcs],
        "summary": operational_summary(request.site, request.risk_label, request.reference_date),
    }


@app.post("/api/checklist/daily")
def daily_checklist(request: DailyChecklistRequest) -> dict:
    return operational_summary(request.site, request.risk_label, request.reference_date)


@app.post("/api/dvr/generate")
def generate_dvr(payload: DVRInput) -> Response:
    try:
        content = generate_dvr_docx(payload)
    except ValidationError as exc:
        raise HTTPException(status_code=422, detail=json.loads(exc.json())) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Errore generazione DVR: {exc}") from exc

    safe_name = "".join(ch if ch.isalnum() else "_" for ch in payload.company.ragione_sociale.lower()).strip("_") or "azienda"
    filename = f"DVR_Calore_{safe_name}_rev_{payload.version}.docx"
    return Response(
        content,
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@app.get("/api/sample")
def sample_payload() -> dict:
    return {
        "company": {
            "ragione_sociale": "Impresa Cliente Esempio S.r.l.",
            "partita_iva": "01234567890",
            "codice_fiscale": "01234567890",
            "rea": "BS-123456",
            "sede_legale": "Via Roma 10, Brescia (BS)",
            "sede_operativa": "Cantiere Tangenziale Nord, Brescia (BS)",
            "ateco": "41.20.00",
            "attivita": "Costruzione edifici e manutenzioni esterne in cantiere",
            "datore_lavoro": "Mario Rossi",
            "rspp": "Ing. Luca Bianchi",
            "medico_competente": "Dott.ssa Anna Verdi",
            "rls": "Paolo Neri",
            "preposto": "Marco Galli",
            "referente_operativo": "Marco Galli",
            "email_referente": "preposto@example.it",
        },
        "sites": [
            {
                "nome": "Cantiere esterno Brescia",
                "comune": "Brescia",
                "provincia": "BS",
                "regione": "Lombardia",
                "indirizzo": "Via del Cantiere 1",
                "lat": 45.5416,
                "lon": 10.2118,
                "settore": "edilizia_outdoor",
                "esposizione_prolungata_sole": True,
                "pubblica_utilita_o_emergenza": False,
                "ombra_disponibile": True,
                "area_fresca_o_climatizzata": False,
                "acqua_disponibile": True,
                "pause_programmate": True,
                "rotazione_addetti": True,
                "termoigrometro_disponibile": True,
                "temperatura_c": 35.0,
                "umidita_relativa": 48,
                "tnw_c": 27.1,
                "tg_c": 41.0,
                "wbgt_outdoor_formula": True,
                "note": "Area esterna con esposizione diretta; ombra mobile e acqua disponibili.",
            }
        ],
        "employees": [
            {
                "id_lavoratore": "GR-001",
                "nome": None,
                "mansione": "Muratori e addetti posa materiali",
                "reparto": "Squadra A",
                "turno": "07:00-16:00",
                "contratto": None,
                "carico_fisico": "intensa",
                "esposizione_sole": "prolungata",
                "indoor_non_climatizzato": False,
                "dpi_indumenti_pesanti": True,
                "lavoro_solitario": False,
                "neoassunto_o_non_acclimatato": False,
                "lavoratore_suscettibile": False,
                "prescrizioni_medico_competente": None,
                "note_attivita": "Movimentazione manuale e posa all'aperto.",
            },
            {
                "id_lavoratore": "GR-002",
                "nome": None,
                "mansione": "Escavatorista / operatore macchina",
                "reparto": "Squadra movimento terra",
                "turno": "07:00-16:00",
                "contratto": None,
                "carico_fisico": "moderata",
                "esposizione_sole": "frequente",
                "indoor_non_climatizzato": False,
                "dpi_indumenti_pesanti": False,
                "lavoro_solitario": True,
                "neoassunto_o_non_acclimatato": False,
                "lavoratore_suscettibile": False,
                "prescrizioni_medico_competente": None,
                "note_attivita": "Attività su mezzo con cabina non sempre climatizzata.",
            },
            {
                "id_lavoratore": "GR-003",
                "nome": None,
                "mansione": "Neoassunti addetti supporto esterno",
                "reparto": "Squadra B",
                "turno": "08:00-17:00",
                "contratto": "Tempo determinato/stagionale",
                "carico_fisico": "moderata",
                "esposizione_sole": "frequente",
                "indoor_non_climatizzato": False,
                "dpi_indumenti_pesanti": True,
                "lavoro_solitario": False,
                "neoassunto_o_non_acclimatato": True,
                "lavoratore_suscettibile": False,
                "prescrizioni_medico_competente": "Acclimatamento progressivo e pause rinforzate.",
                "note_attivita": "Affiancamento a personale esperto.",
            },
        ],
        "worklimate_results": [
            {
                "site_name": "Cantiere esterno Brescia",
                "pgrid": 12345,
                "lat": 45.5416,
                "lon": 10.2118,
                "days": [
                    {
                        "day_key": "2026-07-15",
                        "date_label": "15/07/2026 ore 12:00",
                        "label": "ALTO",
                        "raw_label": "ALTO",
                        "description": "Dato manuale di esempio: Worklimate rischio alto lavoratori al sole con attività intensa.",
                        "source": "Manuale operatore",
                    }
                ],
                "warning": "Dato demo: acquisire screenshot ufficiale nella pratica reale.",
            }
        ],
        "documents": [
            {
                "id": "doc-demo-1",
                "filename": "visura_camerale_cliente.pdf",
                "category": "visura_camerale",
                "mime_type": "application/pdf",
                "size_bytes": 320000,
                "description": "Visura camerale aggiornata acquisita nel fascicolo tecnico.",
                "data_url": None,
                "extracted_text_preview": "Ragione sociale, P.IVA, sede legale, ATECO e REA estratti automaticamente.",
            },
            {
                "id": "doc-demo-2",
                "filename": "screenshot_worklimate_15072026.png",
                "category": "screenshot_worklimate",
                "mime_type": "image/png",
                "size_bytes": 85000,
                "description": "Evidenza Worklimate da allegare al registro giornaliero.",
                "data_url": None,
                "extracted_text_preview": "Rischio ALTO ore 12:00.",
            },
        ],
        "assessment_date": "2026-07-15",
        "alert_settings": {
            "enabled": False,
            "reference_date": "2026-07-15",
            "mode": "oggi",
            "responsible": "Marco Galli",
            "escalation_channel": "WhatsApp aziendale / referente operativo",
            "monitor_interval_minutes": 60,
            "checkpoints": {
                "precheck_1030": True,
                "worklimate_1200": True,
                "pre_stop_1220": True,
                "stop_1230": True,
                "resume_1600": True,
                "measures": True
            },
            "custom": {"time": "15:30", "text": "Controllo extra condizioni lavoratori e punti acqua."}
        },
        "prepared_by": "Safe 4 U Evolution S.r.l.",
        "version": "4.2",
        "status": "bozza",
        "include_employee_names": False,
        "methodology_notes": "Esempio dimostrativo: verificare sempre condizioni reali, misure effettive e indicazioni del Medico competente.",
        "conclusions_notes": "L'esito rosso impone gestione documentata dello stop/ripresa nelle condizioni indicate.",
    }

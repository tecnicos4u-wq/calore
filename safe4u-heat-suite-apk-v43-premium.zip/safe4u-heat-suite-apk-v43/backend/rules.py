from __future__ import annotations

import math
from datetime import date, time
from typing import Dict, Iterable, List, Optional

from models import (
    CalculationComponent,
    Employee,
    LegalTriggerResult,
    OperationalStatus,
    PhysicalLoad,
    RiskClass,
    RiskLabel,
    Sector,
    Site,
    SunExposure,
    WorkerCalculation,
)

LOMBARDIA_START = date(2026, 6, 10)
LOMBARDIA_END = date(2026, 9, 23)
TARGET_SECTORS = {Sector.agricoltura, Sector.florovivaismo, Sector.edilizia_outdoor, Sector.cave}

LEGAL_BASIS_LOMBARDIA = [
    "D.Lgs. 81/2008: valutazione di tutti i rischi, scelta delle misure di prevenzione e protezione, informazione/formazione, gestione emergenze e sorveglianza sanitaria ove prevista.",
    "Titolo VIII D.Lgs. 81/2008: microclima compreso tra gli agenti fisici da valutare, con misure tecniche, organizzative e procedurali coerenti con il rischio.",
    "Linee di indirizzo per la protezione dei lavoratori dal calore e dalla radiazione solare, Conferenza Regioni e Province autonome, 19/06/2025.",
    "Regione Lombardia, Ordinanza n. 484 del 09/06/2026: divieto 12:30-16:00 nei giorni con rischio Worklimate ALTO per lavoratori esposti al sole con attività fisica intensa, nei settori indicati.",
]


def normalize_risk_label(value: str | None) -> RiskLabel:
    if not value:
        return RiskLabel.non_disponibile
    v = value.strip().lower()
    if "alto" in v or "red" in v or "rosso" in v or "emerg" in v:
        return RiskLabel.alto
    if "moder" in v or "medio" in v or "aranc" in v or "orange" in v or "allarme" in v:
        return RiskLabel.moderato
    if "basso" in v or "verde" in v or "green" in v or "yellow" in v or "gial" in v:
        return RiskLabel.basso
    return RiskLabel.non_disponibile


def is_lombardia_ordinance_applicable(site: Site, reference_date: date) -> bool:
    return (
        (site.regione or "").strip().lower() == "lombardia"
        and LOMBARDIA_START <= reference_date <= LOMBARDIA_END
        and site.settore in TARGET_SECTORS
        and site.esposizione_prolungata_sole
    )


def legal_trigger(site: Site, risk_label: RiskLabel, reference_date: date) -> LegalTriggerResult:
    applicable = is_lombardia_ordinance_applicable(site, reference_date)
    high = risk_label == RiskLabel.alto
    excluded = site.pubblica_utilita_o_emergenza
    ban = applicable and high and not excluded
    return LegalTriggerResult(
        ordinanza_applicabile=applicable,
        rischio_alto=high,
        esclusione_pubblica_utilita=excluded,
        divieto_1230_1600=ban,
        fascia_divieto="12:30-16:00" if ban else None,
        messaggio=trigger_message(applicable, high, excluded, ban),
        legal_basis=LEGAL_BASIS_LOMBARDIA,
    )


def trigger_message(applicable: bool, high: bool, excluded: bool, ban: bool) -> str:
    if ban:
        return "STOP operativo: sospendere/riprogrammare attività in esposizione prolungata al sole dalle 12:30 alle 16:00; ripresa non prima delle 16:00 previa nuova verifica."
    if applicable and high and excluded:
        return "Attività esclusa dal divieto solo per pubblica utilità/emergenza: documentare misure organizzative e operative e mantenere rischio residuo accettabile."
    if applicable and not high:
        return "Divieto non attivo oggi; mantenere misure preventive, monitoraggio Worklimate e controllo microclimatico locale."
    return "Ordinanza Lombardia non applicabile al caso specifico; resta la valutazione aziendale del rischio calore/microclima/radiazione solare."


def humidex_from_temp_rh(temp_c: Optional[float], rh: Optional[float]) -> Optional[float]:
    if temp_c is None or rh is None or not (0 <= rh <= 100):
        return None
    a, b = 17.27, 237.7
    gamma = (a * temp_c / (b + temp_c)) + math.log(max(rh, 0.1) / 100.0)
    dew_point = (b * gamma) / (a - gamma)
    e = 6.11 * math.exp(5417.7530 * ((1 / 273.16) - (1 / (273.15 + dew_point))))
    return round(temp_c + 0.5555 * (e - 10.0), 1)


def wbgt_from_site(site: Site) -> Optional[float]:
    if site.tnw_c is None or site.tg_c is None:
        return None
    if site.wbgt_outdoor_formula and site.temperatura_c is not None:
        return round(0.7 * site.tnw_c + 0.2 * site.tg_c + 0.1 * site.temperatura_c, 1)
    return round(0.7 * site.tnw_c + 0.3 * site.tg_c, 1)


def probability_from_exposure(employee: Employee, site: Site) -> tuple[int, str]:
    if employee.esposizione_sole == SunExposure.prolungata or site.esposizione_prolungata_sole:
        return 4, "Esposizione prolungata al sole / area esterna critica"
    if employee.esposizione_sole == SunExposure.frequente:
        return 3, "Esposizione frequente al sole"
    if employee.esposizione_sole == SunExposure.occasionale or employee.indoor_non_climatizzato:
        return 2, "Esposizione occasionale o ambiente caldo non climatizzato"
    return 1, "Esposizione assente o trascurabile"


def damage_from_context(employee: Employee, risk_label: RiskLabel) -> tuple[int, str]:
    if risk_label == RiskLabel.alto:
        base = 4
        note = "Worklimate ALTO: scenario compatibile con stress termico severo/colpo di calore"
    elif risk_label == RiskLabel.moderato:
        base = 3
        note = "Worklimate MODERATO: scenario con possibile malore/stress termico"
    elif risk_label == RiskLabel.basso:
        base = 2
        note = "Worklimate BASSO: disagio/stress lieve da mantenere sotto controllo"
    else:
        base = 2
        note = "Dato meteo non disponibile: applicato principio di cautela"
    if employee.carico_fisico == PhysicalLoad.intensa:
        base = min(4, base + 1)
        note += "; attività fisica intensa"
    return base, note


def aggravating_coefficient(employee: Employee, site: Site) -> tuple[float, List[CalculationComponent]]:
    coeff = 1.0
    comps: List[CalculationComponent] = []
    factors = [
        (employee.carico_fisico == PhysicalLoad.intensa, "Attività fisica intensa", "Incremento produzione metabolica"),
        (employee.dpi_indumenti_pesanti, "DPI/indumenti pesanti", "Ridotta dispersione del calore"),
        (employee.neoassunto_o_non_acclimatato, "Neoassunto/non acclimatato", "Necessario acclimatamento progressivo"),
        (employee.lavoro_solitario, "Lavoro isolato", "Minor intercettazione precoce dei sintomi"),
        (employee.lavoratore_suscettibile, "Suscettibilità individuale", "Flag operativo senza diagnosi; gestire con Medico competente"),
    ]
    if not site.ombra_disponibile or not site.acqua_disponibile or not site.pause_programmate:
        factors.append((True, "Presidi minimi incompleti", "Ombra/acqua/pause non pienamente garantite"))
    for active, name, note in factors:
        if active and coeff < 1.5:
            coeff = round(min(1.5, coeff + 0.1), 2)
            comps.append(CalculationComponent(voce=name, valore="Sì", punteggio=0.1, nota=note))
    return coeff, comps


def mitigation_credit(site: Site) -> tuple[float, List[CalculationComponent]]:
    credit = 0.0
    comps: List[CalculationComponent] = []
    mitigations = [
        (site.acqua_disponibile, 0.08, "Acqua fresca disponibile", "Idratazione accessibile durante il turno"),
        (site.ombra_disponibile, 0.08, "Ombra disponibile", "Pausa e recupero fuori da radiazione diretta"),
        (site.pause_programmate, 0.08, "Pause programmate", "Cicli lavoro/recupero pianificati"),
        (site.rotazione_addetti, 0.05, "Rotazione addetti", "Riduzione esposizione individuale"),
        (site.area_fresca_o_climatizzata, 0.06, "Area fresca/climatizzata", "Recupero termico rafforzato"),
        (site.termoigrometro_disponibile, 0.03, "Monitoraggio locale", "Supporto decisionale con dato microclimatico locale"),
    ]
    for active, points, name, note in mitigations:
        if active:
            credit += points
            comps.append(CalculationComponent(voce=name, valore="Presente", punteggio=points, nota=note))
    credit = round(min(0.35, credit), 2)
    return credit, comps


def classify_score(score: float) -> RiskClass:
    if score > 12:
        return RiskClass.molto_alto
    if score >= 9:
        return RiskClass.alto
    if score >= 5:
        return RiskClass.medio
    return RiskClass.basso


def operational_status(risk_class: RiskClass, legal_ban: bool, risk_label: RiskLabel) -> OperationalStatus:
    if legal_ban or risk_class == RiskClass.molto_alto:
        return OperationalStatus.rosso
    if risk_class == RiskClass.alto or risk_label == RiskLabel.alto:
        return OperationalStatus.giallo
    if risk_label == RiskLabel.non_disponibile:
        return OperationalStatus.grigio
    return OperationalStatus.verde


def employee_label(employee: Employee, include_name: bool = False) -> str:
    if include_name and employee.nome:
        return f"{employee.id_lavoratore} - {employee.nome}"
    return employee.id_lavoratore


def actions_by_risk(site: Site, risk_label: RiskLabel, risk_class: RiskClass, legal_ban: bool, employee: Optional[Employee] = None) -> List[str]:
    actions: List[str] = []
    if legal_ban:
        actions.extend([
            "Sospendere o riprogrammare le attività in esposizione prolungata al sole nella fascia 12:30-16:00.",
            "Ripresa non prima delle 16:00, previa nuova verifica del sito, condizioni dei lavoratori e misure disponibili.",
            "Registrare evidenza Worklimate, ora di stop, attività sospese/rimodulate, preposto e ora di ripresa.",
        ])
    elif risk_label == RiskLabel.alto or risk_class in {RiskClass.alto, RiskClass.molto_alto}:
        actions.extend([
            "Riprogrammare le lavorazioni più gravose nelle fasce fresche e ridurre la permanenza al sole nelle ore centrali.",
            "Aumentare pause in ombra/area fresca e rendere obbligatoria idratazione programmata.",
            "Controllo del preposto almeno ogni 30-60 minuti per sintomi sentinella e lavoro isolato.",
        ])
    elif risk_label == RiskLabel.moderato or risk_class == RiskClass.medio:
        actions.extend([
            "Consentire l'attività solo con misure rafforzate: acqua, ombra, pause e rotazione quando possibile.",
            "Anticipare/posticipare attività ad alto sforzo e verificare aggiornamento Worklimate a metà mattina.",
        ])
    elif risk_label == RiskLabel.non_disponibile:
        actions.extend([
            "Dato Worklimate non disponibile: usare verifica manuale sul portale, misurazioni locali e principio di cautela.",
            "Conservare screenshot/evidenza della verifica e motivazione della decisione aziendale.",
        ])
    else:
        actions.extend([
            "Mantenere misure ordinarie: acqua, ombra, pause, informazione lavoratori e controllo aggiornamento previsionale.",
        ])
    if employee and employee.neoassunto_o_non_acclimatato:
        actions.append("Prevedere acclimatamento progressivo e affiancamento operativo nei primi giorni di esposizione.")
    if employee and employee.lavoratore_suscettibile:
        actions.append("Applicare solo prescrizioni operative del Medico competente; non riportare diagnosi nel DVR.")
    if not site.acqua_disponibile:
        actions.insert(0, "Non avviare attività esposte finché non è garantita acqua fresca in prossimità dell'area di lavoro.")
    return list(dict.fromkeys(actions))


def calculation_for_worker(employee: Employee, site: Site, risk_label: RiskLabel, reference_date: date, include_name: bool = False) -> WorkerCalculation:
    components: List[CalculationComponent] = []
    p, p_note = probability_from_exposure(employee, site)
    d, d_note = damage_from_context(employee, risk_label)
    c, c_comps = aggravating_coefficient(employee, site)
    credit, m_comps = mitigation_credit(site)
    initial_score = round(p * d * c, 1)
    residual_score = round(initial_score * (1 - credit), 1)
    risk_class = classify_score(residual_score)
    lt = legal_trigger(site, risk_label, reference_date)
    status = operational_status(risk_class, lt.divieto_1230_1600, risk_label)
    h = humidex_from_temp_rh(site.temperatura_c, site.umidita_relativa)
    w = wbgt_from_site(site)

    components.extend([
        CalculationComponent(voce="Probabilità / esposizione", valore=str(p), punteggio=p, nota=p_note),
        CalculationComponent(voce="Danno potenziale", valore=str(d), punteggio=d, nota=d_note),
        CalculationComponent(voce="Coefficiente aggravante", valore=str(c), punteggio=c, nota="Limite operativo 1,0-1,5 in base ai fattori presenti."),
        CalculationComponent(voce="Credito misure", valore=f"{int(credit*100)}%", punteggio=credit, nota="Riduzione documentata solo per misure presenti e verificabili."),
    ])
    components.extend(c_comps)
    components.extend(m_comps)
    if h is not None:
        components.append(CalculationComponent(voce="Humidex locale", valore=str(h), punteggio=0, nota="Indice di supporto operativo da temperatura e umidità locali."))
    if w is not None:
        components.append(CalculationComponent(voce="WBGT stimato/misurato", valore=str(w), punteggio=0, nota="Dato da misure locali Tnw/Tg/Ta, se disponibili."))

    return WorkerCalculation(
        employee_id=employee.id_lavoratore,
        employee_label=employee_label(employee, include_name),
        mansione=employee.mansione,
        site_name=site.nome,
        worklimate_label=risk_label,
        probability=p,
        damage=d,
        aggravating_coefficient=c,
        initial_score=initial_score,
        mitigation_credit=credit,
        residual_score=residual_score,
        risk_class=risk_class,
        operational_status=status,
        legal_ban=lt.divieto_1230_1600,
        components=components,
        humidex=h,
        wbgt=w,
        recommended_actions=actions_by_risk(site, risk_label, risk_class, lt.divieto_1230_1600, employee),
        resume_time="16:00" if lt.divieto_1230_1600 else None,
    )


def calculations_for_site(employees: Iterable[Employee], site: Site, risk_label: RiskLabel, reference_date: date, include_names: bool = False) -> List[WorkerCalculation]:
    return [calculation_for_worker(e, site, risk_label, reference_date, include_names) for e in employees]


def dominant_risk(calculations: Iterable[WorkerCalculation]) -> RiskClass:
    rank = {RiskClass.basso: 1, RiskClass.medio: 2, RiskClass.alto: 3, RiskClass.molto_alto: 4}
    result = RiskClass.basso
    for calc in calculations:
        if rank[calc.risk_class] > rank[result]:
            result = calc.risk_class
    return result


def highest_operational_status(calculations: Iterable[WorkerCalculation]) -> OperationalStatus:
    rank = {OperationalStatus.verde: 1, OperationalStatus.giallo: 2, OperationalStatus.rosso: 3, OperationalStatus.grigio: 0}
    result = OperationalStatus.grigio
    for calc in calculations:
        if rank[calc.operational_status] > rank[result]:
            result = calc.operational_status
    return result


def operational_summary(site: Site, risk_label: RiskLabel, reference_date: date) -> Dict[str, object]:
    lt = legal_trigger(site, risk_label, reference_date)
    return {
        "legal_trigger": lt.model_dump(),
        "site": site.model_dump(),
        "risk_label": risk_label.value,
        "humidex": humidex_from_temp_rh(site.temperatura_c, site.umidita_relativa),
        "wbgt": wbgt_from_site(site),
        "actions": actions_by_risk(site, risk_label, RiskClass.alto if risk_label == RiskLabel.alto else RiskClass.medio, lt.divieto_1230_1600),
        "decision": {
            "status": "ROSSO" if lt.divieto_1230_1600 else ("GIALLO" if risk_label in {RiskLabel.alto, RiskLabel.moderato} else "VERDE"),
            "can_work_now": not lt.divieto_1230_1600,
            "stop_window": "12:30-16:00" if lt.divieto_1230_1600 else None,
            "resume_from": "16:00" if lt.divieto_1230_1600 else None,
        },
    }

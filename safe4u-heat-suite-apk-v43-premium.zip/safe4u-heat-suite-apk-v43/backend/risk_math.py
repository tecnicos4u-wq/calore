from __future__ import annotations

import math
from typing import List, Optional

from models import Employee, RiskCalculation, RiskLabel, Site, WorkIntensity, WorklimateResult


RISK_SCORE = {
    RiskLabel.non_disponibile: 2,  # principio di cautela: dato mancante = presidio medio
    RiskLabel.basso: 1,
    RiskLabel.moderato: 2,
    RiskLabel.alto: 3,
}


def max_risk_for_site(results: List[WorklimateResult], site_name: str) -> RiskLabel:
    relevant = [r for r in results if (r.site_name or "").strip().lower() == site_name.strip().lower()]
    if not relevant:
        return RiskLabel.non_disponibile
    max_label = RiskLabel.non_disponibile
    for result in relevant:
        for day in result.days:
            if RISK_SCORE[day.label] > RISK_SCORE[max_label]:
                max_label = day.label
    return max_label


def dew_point_celsius(temperature_c: float, relative_humidity_pct: float) -> float:
    """Magnus approximation. Valid enough for occupational screening, not metrological certification."""
    rh = max(1e-6, min(100.0, relative_humidity_pct))
    a = 17.27
    b = 237.7
    alpha = ((a * temperature_c) / (b + temperature_c)) + math.log(rh / 100.0)
    return (b * alpha) / (a - alpha)


def humidex(temperature_c: float, relative_humidity_pct: float) -> float:
    dp = dew_point_celsius(temperature_c, relative_humidity_pct)
    e = 6.11 * math.exp(5417.7530 * ((1 / 273.16) - (1 / (273.15 + dp))))
    return temperature_c + 0.5555 * (e - 10.0)


def humidex_label(value: Optional[float]) -> RiskLabel:
    if value is None:
        return RiskLabel.non_disponibile
    if value >= 40:
        return RiskLabel.alto
    if value >= 30:
        return RiskLabel.moderato
    return RiskLabel.basso


def exposure_score(site: Site) -> int:
    if not site.esposizione_prolungata_sole and site.settore.value != "indoor_non_climatizzato":
        return 1
    hours = site.durata_esposizione_ore
    if hours is None:
        return 3 if site.turno_prevalente.value == "centrale_1230_1600" else 2
    if hours >= 4:
        return 3
    if hours >= 2:
        return 2
    return 1


def workload_score(site: Site) -> int:
    if site.intensita_lavoro == WorkIntensity.intensa:
        return 3
    if site.intensita_lavoro == WorkIntensity.moderata:
        return 2
    return 1


def vulnerability_score(employees: List[Employee]) -> int:
    if not employees:
        return 2
    points = 0
    for e in employees:
        flags = [
            e.neoassunto_o_non_acclimatato,
            e.lavoratore_suscettibile,
            e.dpi_indumenti_pesanti,
            e.lavoro_solitario,
            e.indoor_non_climatizzato,
        ]
        points += sum(1 for flag in flags if flag)
    avg = points / max(1, len(employees))
    if avg >= 2:
        return 3
    if avg >= 0.75:
        return 2
    return 1


def mitigation_credit(site: Site) -> int:
    m = site.misure
    controls = [
        m.acqua_fresca_disponibile,
        m.ombra_o_area_fresca,
        m.pause_programmate,
        m.turni_riprogrammabili,
        m.acclimatamento_progressivo,
        m.buddy_system,
        m.piano_emergenza_calore,
        m.formazione_erogata,
        m.dpi_ottimizzati,
        m.monitoraggio_locale,
        m.comunicazione_preposti,
    ]
    count = sum(1 for item in controls if item)
    if count >= 9:
        return 3
    if count >= 6:
        return 2
    if count >= 3:
        return 1
    return 0


def classify_residual(index: int) -> tuple[str, str]:
    if index >= 24:
        return "CRITICO", "Immediata"
    if index >= 12:
        return "ALTO", "Alta"
    if index >= 6:
        return "MEDIO", "Media"
    return "BASSO", "Ordinaria"


def calculate_site_risk(site: Site, employees: List[Employee], results: List[WorklimateResult]) -> RiskCalculation:
    wl = max_risk_for_site(results, site.nome)
    h_value: Optional[float] = None
    h_label = RiskLabel.non_disponibile
    notes: List[str] = []

    if site.misurazione_locale and site.misurazione_locale.air_temperature_c is not None and site.misurazione_locale.relative_humidity_pct is not None:
        h_value = round(humidex(site.misurazione_locale.air_temperature_c, site.misurazione_locale.relative_humidity_pct), 1)
        h_label = humidex_label(h_value)
        notes.append("Humidex calcolato da temperatura e umidita locali; valore di supporto, non sostitutivo della verifica Worklimate.")
    else:
        notes.append("Misurazione locale assente o incompleta: mantenere osservazione in campo e registrare eventuale termo-igrometro/humidex/WBGT.")

    hazard = max(RISK_SCORE[wl], RISK_SCORE[h_label])
    exp = exposure_score(site)
    work = workload_score(site)
    vuln = vulnerability_score(employees)
    mitig = mitigation_credit(site)
    gross = hazard * exp * max(work, vuln)
    residual = max(1, gross - (mitig * 2))
    residual_class, priority = classify_residual(residual)

    if wl == RiskLabel.non_disponibile:
        notes.append("Dato Worklimate non disponibile nel payload: applicato livello cautelativo medio.")
    if site.pubblica_utilita_o_emergenza:
        notes.append("Sito marcato pubblica utilita/emergenza: il divieto richiede comunque misure organizzative e operative documentate.")

    return RiskCalculation(
        site_name=site.nome,
        worklimate_label=wl,
        humidex=h_value,
        humidex_label=h_label,
        hazard_score=hazard,
        exposure_score=exp,
        workload_score=work,
        vulnerability_score=vuln,
        mitigation_credit=mitig,
        gross_index=gross,
        residual_index=residual,
        residual_class=residual_class,
        priority=priority,
        formula="IR lordo = Pericolo x Esposizione x max(Intensita, Vulnerabilita); IR residuo = IR lordo - 2 x crediti misure",
        notes=notes,
    )

from __future__ import annotations

from datetime import date, datetime

import requests

from models import GeoRiskRequest, RiskLabel, WorklimateDay, WorklimateResult
from rules import normalize_risk_label


class WorklimateClient:
    """Best-effort public Worklimate client.

    The API can change; the app always allows manual insertion of the official
    Worklimate level and requires documentary evidence in the daily register.
    """

    def __init__(self, timeout: float = 8.0) -> None:
        self.timeout = timeout

    def georisk(self, request: GeoRiskRequest) -> WorklimateResult:
        site = request.site
        if site.lat is None or site.lon is None:
            return WorklimateResult(
                site_name=site.nome,
                lat=site.lat,
                lon=site.lon,
                days=[],
                warning="Coordinate assenti: inserire lat/lon o usare la geolocalizzazione del telefono.",
            )
        # Endpoint intentionally defensive. When unavailable the operator must use manual evidence.
        candidates = [
            "https://app.worklimate.it/api/v1/ordinanza-caldo-lavoro",
            "https://app.worklimate.it/api/ordinanza-caldo-lavoro",
        ]
        last_error = None
        for endpoint in candidates:
            try:
                res = requests.get(endpoint, params={"lat": site.lat, "lon": site.lon}, timeout=self.timeout)
                if res.status_code >= 400:
                    last_error = f"HTTP {res.status_code}"
                    continue
                data = res.json()
                days = self._parse_days(data)
                if days:
                    return WorklimateResult(site_name=site.nome, lat=site.lat, lon=site.lon, updated_at=datetime.utcnow(), days=days, raw=data)
            except Exception as exc:  # pragma: no cover - network dependent
                last_error = str(exc)
        return WorklimateResult(
            site_name=site.nome,
            lat=site.lat,
            lon=site.lon,
            days=[],
            warning=f"Worklimate non interrogabile automaticamente ({last_error or 'endpoint non disponibile'}). Verificare manualmente il portale ufficiale e allegare screenshot.",
        )

    def _parse_days(self, data: object) -> list[WorklimateDay]:
        rows: list[dict] = []
        if isinstance(data, dict):
            for key in ("days", "previsioni", "forecast", "data", "features"):
                val = data.get(key)
                if isinstance(val, list):
                    rows = [x for x in val if isinstance(x, dict)]
                    break
            if not rows and any(k in data for k in ("rischio", "risk", "label")):
                rows = [data]
        elif isinstance(data, list):
            rows = [x for x in data if isinstance(x, dict)]
        days: list[WorklimateDay] = []
        for idx, row in enumerate(rows[:7]):
            label = row.get("label") or row.get("rischio") or row.get("risk") or row.get("livello") or row.get("risk_label")
            day = row.get("date") or row.get("giorno") or row.get("day") or str(date.today())
            days.append(
                WorklimateDay(
                    day_key=str(day),
                    date_label=str(day),
                    label=normalize_risk_label(str(label) if label is not None else None),
                    raw_label=str(label) if label is not None else None,
                    description=row.get("description") or row.get("descrizione"),
                    long_description=row.get("long_description") or row.get("note"),
                    source="Worklimate/API",
                )
            )
        return days

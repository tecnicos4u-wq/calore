"""DVR Calore Pro backend."""

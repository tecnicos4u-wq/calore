from __future__ import annotations

import base64
import os
import re
import tempfile
from collections import defaultdict
from datetime import date
from io import BytesIO
from typing import Dict, Iterable, List, Optional, Tuple

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from docx import Document
from docx.enum.section import WD_SECTION_START
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Inches, Pt, RGBColor

from models import DVRInput, DocumentAttachment, RiskClass, RiskLabel, Site, WorklimateResult, WorkerCalculation
from rules import calculations_for_site, dominant_risk, highest_operational_status, legal_trigger, operational_summary, wbgt_from_site

BRAND_NAVY = "111A4C"
BRAND_BLUE = "1D4ED8"
BRAND_GOLD = "D9A72E"
BRAND_CYAN = "06B6D4"
BRAND_GREEN = "16A34A"
BRAND_YELLOW = "FACC15"
BRAND_ORANGE = "F97316"
BRAND_RED = "DC2626"
BRAND_GRAY = "64748B"
BRAND_LIGHT = "E2E8F0"
BRAND_BG = "F8FAFC"
WHITE = "FFFFFF"

RISK_CLASS_FILL = {
    RiskClass.basso: "BBF7D0",
    RiskClass.medio: "FEF3C7",
    RiskClass.alto: "FED7AA",
    RiskClass.molto_alto: "FECACA",
}
RISK_CLASS_TEXT = {
    RiskClass.basso: "166534",
    RiskClass.medio: "92400E",
    RiskClass.alto: "9A3412",
    RiskClass.molto_alto: "991B1B",
}

RISK_LABEL_FILL = {
    RiskLabel.non_disponibile: "CBD5E1",
    RiskLabel.basso: "BBF7D0",
    RiskLabel.moderato: "FEF3C7",
    RiskLabel.alto: "FECACA",
}

ASSET_LOGO = os.path.join(os.path.dirname(__file__), "assets", "safe4u_logo.png")


def generate_dvr_docx(payload: DVRInput) -> bytes:
    doc = Document()
    setup_document(doc, payload)

    risks = risk_by_site(payload)
    calculations = {
        site.nome: calculations_for_site(
            payload.employees,
            site,
            risks.get(site.nome, RiskLabel.non_disponibile),
            payload.assessment_date,
            include_names=payload.include_employee_names,
        )
        for site in payload.sites
    }

    add_cover(doc, payload, calculations, risks)
    add_revision_table(doc, payload)
    add_static_toc(doc)
    add_executive_summary(doc, payload, calculations, risks)
    add_normative_scope(doc)
    add_company_section(doc, payload)
    add_document_intake_section(doc, payload)
    add_site_section(doc, payload, risks)
    add_methodology_section(doc, payload)
    add_visual_charts_section(doc, payload, calculations, risks)
    add_calculation_section(doc, payload, calculations, risks)
    add_legal_decision_section(doc, payload, risks)
    add_prevention_measures_section(doc, payload, calculations, risks)
    add_daily_procedure_section(doc)
    add_mobile_alerts_section(doc, payload, risks)
    add_emergency_section(doc)
    add_training_health_section(doc)
    add_monitoring_section(doc, payload, risks)
    add_attachment_gallery(doc, payload)
    add_conclusions_section(doc, payload, calculations, risks)
    add_signature_section(doc, payload)

    buffer = BytesIO()
    doc.save(buffer)
    return buffer.getvalue()


def setup_document(doc: Document, payload: DVRInput) -> None:
    section = doc.sections[0]
    section.top_margin = Cm(1.7)
    section.bottom_margin = Cm(1.5)
    section.left_margin = Cm(1.7)
    section.right_margin = Cm(1.7)

    styles = doc.styles
    styles["Normal"].font.name = "Arial"
    styles["Normal"].font.size = Pt(9.5)
    styles["Normal"]._element.rPr.rFonts.set(qn("w:eastAsia"), "Arial")

    for name, size, color in [("Title", 24, BRAND_NAVY), ("Heading 1", 16, BRAND_NAVY), ("Heading 2", 12, BRAND_BLUE), ("Heading 3", 10.5, BRAND_NAVY)]:
        style = styles[name]
        style.font.name = "Arial"
        style.font.size = Pt(size)
        style.font.color.rgb = RGBColor.from_string(color)
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "Arial")

    styles["Heading 1"].paragraph_format.space_before = Pt(12)
    styles["Heading 1"].paragraph_format.space_after = Pt(6)
    styles["Heading 2"].paragraph_format.space_before = Pt(8)
    styles["Heading 2"].paragraph_format.space_after = Pt(4)

    cp = doc.core_properties
    cp.title = f"DVR Calore - {payload.company.ragione_sociale}"
    cp.subject = "Valutazione rischio calore, microclima e radiazione solare"
    cp.author = "Safe 4 U Evolution S.r.l."
    cp.comments = "Generato con Safe 4 U Heat DVR. Validare in campo e firmare dai soggetti aziendali competenti."

    add_header_footer(doc, payload)


def add_header_footer(doc: Document, payload: DVRInput) -> None:
    section = doc.sections[0]
    header = section.header
    table = header.add_table(rows=1, cols=3, width=Inches(7.2))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    widths = [Inches(1.1), Inches(3.6), Inches(2.5)]
    for i, w in enumerate(widths):
        table.cell(0, i).width = w
    left, center, right = table.rows[0].cells
    if os.path.exists(ASSET_LOGO):
        p = left.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        p.add_run().add_picture(ASSET_LOGO, width=Inches(0.75))
    else:
        set_cell(left, "S4U", fill=BRAND_NAVY, color=WHITE, bold=True, align="center")
    set_cell(center, "SAFE 4 U EVOLUTION S.R.L. - DVR CALORE", fill=BRAND_NAVY, color=WHITE, bold=True, align="center")
    set_cell(right, f"{payload.company.ragione_sociale}\nRev. {payload.version}", fill=BRAND_NAVY, color=WHITE, bold=True, align="right")

    footer = section.footer
    p = footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run("Documento operativo riservato - copia controllata | Pag. ")
    add_page_number(p)
    p.add_run(" di ")
    add_num_pages(p)
    for run in p.runs:
        run.font.size = Pt(8)
        run.font.color.rgb = RGBColor.from_string(BRAND_GRAY)


def add_page_number(paragraph):
    run = paragraph.add_run()
    fld_char1 = OxmlElement("w:fldChar")
    fld_char1.set(qn("w:fldCharType"), "begin")
    instr_text = OxmlElement("w:instrText")
    instr_text.set(qn("xml:space"), "preserve")
    instr_text.text = "PAGE"
    fld_char2 = OxmlElement("w:fldChar")
    fld_char2.set(qn("w:fldCharType"), "end")
    run._r.append(fld_char1)
    run._r.append(instr_text)
    run._r.append(fld_char2)


def add_num_pages(paragraph):
    run = paragraph.add_run()
    fld_char1 = OxmlElement("w:fldChar")
    fld_char1.set(qn("w:fldCharType"), "begin")
    instr_text = OxmlElement("w:instrText")
    instr_text.set(qn("xml:space"), "preserve")
    instr_text.text = "NUMPAGES"
    fld_char2 = OxmlElement("w:fldChar")
    fld_char2.set(qn("w:fldCharType"), "end")
    run._r.append(fld_char1)
    run._r.append(instr_text)
    run._r.append(fld_char2)


def add_cover(doc: Document, payload: DVRInput, calculations: Dict[str, list[WorkerCalculation]], risks: Dict[str, RiskLabel]) -> None:
    p_logo = doc.add_paragraph()
    p_logo.alignment = WD_ALIGN_PARAGRAPH.CENTER
    if os.path.exists(ASSET_LOGO):
        p_logo.add_run().add_picture(ASSET_LOGO, width=Inches(1.65))

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run("DOCUMENTO DI VALUTAZIONE DEL RISCHIO")
    run.bold = True
    run.font.size = Pt(20)
    run.font.color.rgb = RGBColor.from_string(BRAND_NAVY)
    p2 = doc.add_paragraph()
    p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p2.add_run("Calore, microclima severo caldo e radiazione solare")
    r.bold = True
    r.font.size = Pt(17)
    r.font.color.rgb = RGBColor.from_string(BRAND_GOLD)

    max_class = max_risk_from_calculations(calculations)
    ban_count = count_legal_bans(payload, risks)
    badge = doc.add_table(rows=1, cols=1)
    badge.alignment = WD_TABLE_ALIGNMENT.CENTER
    badge_text = f"ESITO SINTETICO: {max_class.value}"
    if ban_count:
        badge_text += " | STOP 12:30-16:00 ATTIVO NEI CASI PREVISTI"
    fill = RISK_CLASS_FILL.get(max_class, BRAND_LIGHT)
    set_cell(badge.cell(0, 0), badge_text, fill=fill, color=RISK_CLASS_TEXT.get(max_class, BRAND_NAVY), bold=True, align="center")

    doc.add_paragraph()
    info = doc.add_table(rows=9, cols=2)
    style_table(info)
    rows = [
        ("Azienda valutata", payload.company.ragione_sociale),
        ("Sede legale", payload.company.sede_legale or "Da completare / da visura"),
        ("P.IVA / C.F.", f"{payload.company.partita_iva or '-'} / {payload.company.codice_fiscale or '-'}"),
        ("Sito/i", "; ".join(site.nome for site in payload.sites) or "Da completare"),
        ("Data valutazione", fmt_date(payload.assessment_date)),
        ("Versione / stato", f"Rev. {payload.version} - {payload.status.value.upper()}"),
        ("Redatto con supporto tecnico", "Safe 4 U Evolution S.r.l."),
        ("Redatto da", payload.prepared_by or "Da completare"),
        ("Fascicolo istruttorio", "Documentazione acquisita e conservata agli atti" if payload.documents else "Da completare"),
    ]
    for idx, (k, v) in enumerate(rows):
        set_cell(info.cell(idx, 0), k, fill=BRAND_NAVY, color=WHITE, bold=True)
        set_cell(info.cell(idx, 1), v)

    doc.add_paragraph()
    dashboard = doc.add_table(rows=2, cols=4)
    dashboard.alignment = WD_TABLE_ALIGNMENT.CENTER
    headers = ["Siti", "Lavoratori/gruppi", "Rischio residuo max", "Divieto operativo"]
    values = [str(len(payload.sites)), str(len(payload.employees)), max_class.value, "ATTIVO" if ban_count else "Non attivo"]
    for i, h in enumerate(headers):
        set_cell(dashboard.cell(0, i), h, fill=BRAND_LIGHT, color=BRAND_NAVY, bold=True, align="center")
        fill2 = RISK_CLASS_FILL.get(max_class, BRAND_LIGHT) if i == 2 else (BRAND_RED if i == 3 and ban_count else BRAND_BG)
        color2 = RISK_CLASS_TEXT.get(max_class, BRAND_NAVY) if i == 2 else (WHITE if i == 3 and ban_count else BRAND_NAVY)
        set_cell(dashboard.cell(1, i), values[i], fill=fill2, color=color2, bold=True, align="center")

    doc.add_paragraph()
    add_callout(doc, "Nota", "Il presente elaborato integra il DVR aziendale e deve essere validato dal Datore di Lavoro con RSPP, Medico Competente ove previsto, RLS/RLST e preposti interessati. Le diagnosi, patologie, farmaci e informazioni sanitarie di dettaglio non sono riportate nel documento, in applicazione del principio di minimizzazione.", BRAND_LIGHT, BRAND_NAVY)
    doc.add_page_break()


def add_revision_table(doc: Document, payload: DVRInput) -> None:
    add_h1(doc, "Controllo documento")
    table = doc.add_table(rows=5, cols=4)
    style_table(table)
    fill_header(table, ["Rev.", "Data", "Oggetto", "Responsabile"])
    rows = [
        (payload.version, fmt_date(payload.assessment_date), "Emissione/aggiornamento valutazione rischio calore", payload.prepared_by or "Da completare"),
        ("", "", "Verifica RSPP", ""),
        ("", "", "Parere Medico competente, ove previsto", ""),
        ("", "", "Consultazione RLS/RLST", ""),
    ]
    for r, row in enumerate(rows, start=1):
        for c, v in enumerate(row):
            set_cell(table.cell(r, c), v)
    add_small_note(doc, "Aggiornare il documento in caso di modifica organizzativa, nuova mansione, nuovo cantiere, evento sentinella, indicazioni sanitarie o aggiornamento normativo/ordinanza locale.")


def add_static_toc(doc: Document) -> None:
    add_h1(doc, "Indice operativo")
    items = [
        "Executive summary visuale",
        "Riferimenti normativi e campo di applicazione",
        "Dati aziendali e organigramma sicurezza",
        "Fascicolo istruttorio e fonti documentali",
        "Descrizione sito/cantiere e condizioni meteoclimatiche",
        "Metodologia di valutazione, Worklimate, Humidex e WBGT",
        "Grafici: timeline, matrice e rischio mansioni",
        "Calcoli per mansione/gruppo omogeneo",
        "Applicazione ordinanza Lombardia e decisioni operative",
        "Misure di prevenzione e protezione",
        "Procedura di controllo operativo, registrazioni e allerta",
        "Emergenza caldo, formazione, sorveglianza sanitaria",
        "Conclusioni e sottoscrizione",
    ]
    for i, item in enumerate(items, start=1):
        p = doc.add_paragraph()
        p.add_run(f"{i}. ").bold = True
        p.add_run(item)
    doc.add_page_break()


def add_executive_summary(doc: Document, payload: DVRInput, calculations: Dict[str, list[WorkerCalculation]], risks: Dict[str, RiskLabel]) -> None:
    add_h1(doc, "Executive summary")
    max_class = max_risk_from_calculations(calculations)
    status = max_status_from_calculations(calculations)
    ban_count = count_legal_bans(payload, risks)
    add_callout(
        doc,
        "Giudizio sintetico",
        f"La valutazione restituisce rischio residuo massimo {max_class.value} e stato operativo {status.value}. "
        + ("Nei casi indicati è presente stop operativo 12:30-16:00." if ban_count else "Non risulta attivo il divieto operativo 12:30-16:00 alla data/sito valutati."),
        RISK_CLASS_FILL.get(max_class, BRAND_LIGHT),
        RISK_CLASS_TEXT.get(max_class, BRAND_NAVY),
    )
    summary = doc.add_table(rows=1 + len(payload.sites), cols=7)
    style_table(summary)
    fill_header(summary, ["Sito", "Comune", "Settore", "Worklimate", "Humidex", "WBGT", "Decisione"])
    for r, site in enumerate(payload.sites, start=1):
        risk = risks.get(site.nome, RiskLabel.non_disponibile)
        lt = legal_trigger(site, risk, payload.assessment_date)
        ops = operational_summary(site, risk, payload.assessment_date)
        values = [
            site.nome,
            site.comune or "-",
            sector_label(site.settore.value),
            risk.value,
            str(ops.get("humidex") or "n.d."),
            str(ops.get("wbgt") or "n.d."),
            "STOP 12:30-16:00" if lt.divieto_1230_1600 else lt.messaggio[:70] + ("..." if len(lt.messaggio) > 70 else ""),
        ]
        for c, v in enumerate(values):
            fill = BRAND_BG
            color = BRAND_NAVY
            if c == 3:
                fill = RISK_LABEL_FILL.get(risk, BRAND_LIGHT)
            if c == 6 and lt.divieto_1230_1600:
                fill, color = BRAND_RED, WHITE
            set_cell(summary.cell(r, c), v, fill=fill, color=color, bold=(c in {3, 6}), align="center" if c in {3, 4, 5} else "left")

    add_h2(doc, "Azioni prioritarie")
    priorities = collect_priority_actions(calculations, payload, risks)
    for action in priorities[:10]:
        add_check_item(doc, action)


def add_normative_scope(doc: Document) -> None:
    add_h1(doc, "Riferimenti normativi e campo di applicazione")
    doc.add_paragraph(
        "La presente valutazione riguarda il rischio da calore, microclima severo caldo e radiazione solare nelle attività all'aperto, in ambienti chiusi non climatizzati o in condizioni in cui il microclima è influenzato dalle condizioni meteoclimatiche esterne."
    )
    refs = [
        "D.Lgs. 81/2008: oggetto e modalità della valutazione dei rischi, misure di prevenzione e protezione, ruoli dell'organizzazione aziendale, informazione/formazione e sorveglianza sanitaria ove prevista.",
        "D.Lgs. 81/2008, Titolo VIII, agenti fisici: microclima e condizioni di esposizione da valutare con personale competente, buone prassi e aggiornamento periodico.",
        "Linee di indirizzo per la protezione dei lavoratori dal calore e dalla radiazione solare, Conferenza delle Regioni e Province autonome, 19/06/2025.",
        "Ordinanza Regione Lombardia n. 484 del 09/06/2026, ove applicabile, per attività agricole, florovivaistiche, cantieri edili all'aperto e cave in condizioni di esposizione prolungata al sole.",
        "Eventuali ordinanze comunali/sindacali più restrittive e indicazioni del committente/coordinatore, da allegare alla pratica.",
    ]
    for ref in refs:
        doc.add_paragraph(ref, style="List Bullet")
    add_callout(doc, "Ambito applicativo", "Il documento distingue obbligo/divieto da ordinanza, valutazione aziendale del rischio residuo e raccomandazioni operative aggiuntive. Il divieto non esaurisce gli obblighi di prevenzione: anche fuori dalla fascia 12:30-16:00 il rischio residuo deve essere gestito.", BRAND_LIGHT, BRAND_NAVY)


def add_company_section(doc: Document, payload: DVRInput) -> None:
    add_h1(doc, "Dati identificativi azienda e organigramma sicurezza")
    c = payload.company
    table = doc.add_table(rows=9, cols=2)
    style_table(table)
    rows = [
        ("Ragione sociale", c.ragione_sociale),
        ("P.IVA / C.F.", f"{c.partita_iva or '-'} / {c.codice_fiscale or '-'}"),
        ("REA", c.rea or "Da visura"),
        ("Sede legale", c.sede_legale or "Da completare"),
        ("Sede operativa", c.sede_operativa or "Da completare"),
        ("ATECO / attività", f"{c.ateco or '-'} - {c.attivita or 'Da descrivere'}"),
        ("Datore di lavoro", c.datore_lavoro or "Da completare"),
        ("RSPP / MC / RLS", f"{c.rspp or '-'} / {c.medico_competente or '-'} / {c.rls or '-'}"),
        ("Preposto / referente", f"{c.preposto or '-'} / {c.referente_operativo or '-'}"),
    ]
    for idx, (k, v) in enumerate(rows):
        set_cell(table.cell(idx, 0), k, fill=BRAND_NAVY, color=WHITE, bold=True)
        set_cell(table.cell(idx, 1), v)
    doc.add_paragraph("I dati aziendali devono essere verificati su visura camerale aggiornata e coerenti con il DVR generale e le nomine del sistema prevenzione.")


def add_document_intake_section(doc: Document, payload: DVRInput) -> None:
    add_h1(doc, "Fascicolo istruttorio e fonti documentali")
    doc.add_paragraph(
        "La valutazione è stata elaborata dal consulente sulla base delle informazioni aziendali dichiarate, "
        "della documentazione resa disponibile dal Datore di Lavoro e delle evidenze tecniche acquisite per il sito/lavorazioni oggetto di verifica. "
        "I modelli di raccolta dati compilati dal cliente e le evidenze operative sono conservati nel fascicolo tecnico della pratica; "
        "nel presente DVR sono riportati solo gli elementi tecnicamente rilevanti ai fini della valutazione, delle decisioni operative e delle misure di prevenzione."
    )
    if not payload.documents:
        add_warning_box(doc, "Fascicolo istruttorio da completare", "Prima dell'emissione definitiva verificare disponibilità di visura aggiornata, evidenza Worklimate, elenco gruppi omogenei/lavoratori e documentazione delle misure presenti nel sito.")
        return
    categories = defaultdict(int)
    for a in payload.documents:
        categories[a.category.value] += 1
    table = doc.add_table(rows=1 + len(categories), cols=3)
    style_table(table)
    fill_header(table, ["Area documentale", "Evidenze acquisite", "Utilizzo nel DVR"])
    purpose = {
        "visura_camerale": "Verifica anagrafica aziendale e dati ufficiali",
        "screenshot_worklimate": "Riscontro fascia rischio e applicazione ordinanza",
        "elenco_lavoratori": "Definizione mansioni/gruppi omogenei e calcoli",
        "planimetria_o_layout": "Localizzazione punti acqua, ombra e aree recupero",
        "foto_misure": "Evidenza misure presenti e miglioramenti",
        "dvr_generale": "Coordinamento con DVR aziendale e organizzazione sicurezza",
        "nomine_sicurezza": "Verifica ruoli prevenzione e responsabilità operative",
        "procedure": "Coerenza procedure aziendali e istruzioni preposti",
        "ordinanza": "Verifica contesto prescrittivo territoriale",
        "altro": "Elemento istruttorio integrativo",
    }
    for r, (cat, count) in enumerate(sorted(categories.items()), start=1):
        set_cell(table.cell(r, 0), cat.replace("_", " ").title(), fill=BRAND_LIGHT, color=BRAND_NAVY, bold=True)
        set_cell(table.cell(r, 1), f"{count} elemento/i acquisito/i", align="center")
        set_cell(table.cell(r, 2), purpose.get(cat, "Elemento istruttorio integrativo"))
    add_small_note(doc, "Il dettaglio dei file ricevuti rimane nel fascicolo digitale di commessa. Nel DVR non vengono riportati dati eccedenti o documenti di raccolta non necessari alla valutazione finale.")


def add_site_section(doc: Document, payload: DVRInput, risks: Dict[str, RiskLabel]) -> None:
    add_h1(doc, "Descrizione sito/cantiere e condizioni operative")
    for site in payload.sites:
        add_h2(doc, site.nome)
        risk = risks.get(site.nome, RiskLabel.non_disponibile)
        lt = legal_trigger(site, risk, payload.assessment_date)
        rows = [
            ("Localizzazione", f"{site.indirizzo or '-'} - {site.comune or '-'} ({site.provincia or '-'}) - {site.regione}"),
            ("Coordinate", f"{site.lat if site.lat is not None else 'n.d.'}, {site.lon if site.lon is not None else 'n.d.'}"),
            ("Settore", sector_label(site.settore.value)),
            ("Esposizione prolungata al sole", yesno(site.esposizione_prolungata_sole)),
            ("Worklimate / rischio decisionale", risk.value),
            ("Ombra / acqua / pause", f"{yesno(site.ombra_disponibile)} / {yesno(site.acqua_disponibile)} / {yesno(site.pause_programmate)}"),
            ("Temperatura / umidità / Humidex", f"{site.temperatura_c or 'n.d.'} °C / {site.umidita_relativa or 'n.d.'}% / {operational_summary(site, risk, payload.assessment_date).get('humidex') or 'n.d.'}"),
            ("WBGT", f"{wbgt_from_site(site) or 'n.d.'}"),
            ("Applicazione ordinanza", lt.messaggio),
            ("Note sito", site.note or "-"),
        ]
        table = doc.add_table(rows=len(rows), cols=2)
        style_table(table)
        for idx, (k, v) in enumerate(rows):
            set_cell(table.cell(idx, 0), k, fill=BRAND_LIGHT, color=BRAND_NAVY, bold=True)
            set_cell(table.cell(idx, 1), v)


def add_methodology_section(doc: Document, payload: DVRInput) -> None:
    add_h1(doc, "Metodologia di valutazione")
    doc.add_paragraph("La metodologia combina fonte previsionale Worklimate, dati del sito, esposizione al sole, carico fisico, fattori aggravanti individuali/organizzativi e misure preventive esistenti. Lo score interno non è un indice di legge: è un indice operativo aziendale per rendere tracciabile la decisione e graduare le misure.")
    add_h2(doc, "Indice Operativo Aziendale Rischio Calore")
    formula = doc.add_table(rows=4, cols=2)
    style_table(formula)
    rows = [
        ("Formula", "R = P x D x C"),
        ("P - Probabilità/esposizione", "1 assente/trascurabile; 2 occasionale; 3 frequente; 4 prolungata al sole o ambiente caldo critico"),
        ("D - Danno potenziale", "1 disagio lieve; 2 stress moderato; 3 possibile malore/infortunio; 4 colpo di calore/evento grave"),
        ("C - Coefficiente aggravante", "1,0-1,5: attività intensa, DPI/indumenti pesanti, non acclimatazione, lavoro isolato, suscettibilità operativa, presidi incompleti"),
    ]
    for idx, (k, v) in enumerate(rows):
        set_cell(formula.cell(idx, 0), k, fill=BRAND_NAVY, color=WHITE, bold=True)
        set_cell(formula.cell(idx, 1), v)
    doc.add_paragraph("Il rischio residuo è calcolato applicando un credito massimo del 35% alle misure realmente presenti e verificabili: acqua, ombra, pause, rotazione, area fresca/climatizzata e monitoraggio locale.")
    add_h2(doc, "Supporto strumentale: Humidex e WBGT")
    doc.add_paragraph("Quando disponibili, temperatura, umidità e dati strumentali locali sono usati come supporto decisionale. L'Humidex deriva da temperatura e umidità relativa; il WBGT può essere calcolato con Tnw, Tg e, per esterno con carico solare, Ta. In assenza di misure, resta obbligatorio il controllo operativo e l'uso prudenziale del dato Worklimate/portale ufficiale.")
    if payload.methodology_notes:
        add_h2(doc, "Note metodologiche aziendali")
        doc.add_paragraph(payload.methodology_notes)


def add_visual_charts_section(doc: Document, payload: DVRInput, calculations: Dict[str, list[WorkerCalculation]], risks: Dict[str, RiskLabel]) -> None:
    add_h1(doc, "Dashboard grafica del rischio")
    all_calcs = [c for arr in calculations.values() for c in arr]
    legal_active = count_legal_bans(payload, risks) > 0
    add_picture_from_bytes(doc, chart_timeline(legal_active), "Figura 1 - Timeline operativa giornaliera")
    add_picture_from_bytes(doc, chart_risk_matrix(), "Figura 2 - Matrice P x D con fasce di rischio")
    if all_calcs:
        add_picture_from_bytes(doc, chart_risk_bars(all_calcs), "Figura 3 - Rischio residuo per mansione/gruppo omogeneo")
        add_picture_from_bytes(doc, chart_before_after(all_calcs), "Figura 4 - Rischio iniziale e residuo dopo misure")
    else:
        add_warning_box(doc, "Grafici mansioni non disponibili", "Inserire almeno un lavoratore o gruppo omogeneo per generare grafici di rischio per mansione.")


def add_calculation_section(doc: Document, payload: DVRInput, calculations: Dict[str, list[WorkerCalculation]], risks: Dict[str, RiskLabel]) -> None:
    add_h1(doc, "Valutazione rischio per mansione/gruppo omogeneo")
    if not payload.employees:
        add_warning_box(doc, "Lavoratori/gruppi mancanti", "Il DVR deve contenere almeno gruppi omogenei/mansioni esposte. Completare elenco lavoratori o importare CSV/Excel dalla schermata Documenti/Lavoratori.")
        return
    for site in payload.sites:
        add_h2(doc, f"Sito: {site.nome}")
        risk = risks.get(site.nome, RiskLabel.non_disponibile)
        table = doc.add_table(rows=1 + len(calculations.get(site.nome, [])), cols=10)
        style_table(table)
        fill_header(table, ["ID/gruppo", "Mansione", "Worklimate", "P", "D", "C", "R iniziale", "Credito", "R residuo", "Classe"])
        for r, calc in enumerate(calculations.get(site.nome, []), start=1):
            values = [
                calc.employee_label,
                calc.mansione,
                calc.worklimate_label.value,
                str(calc.probability),
                str(calc.damage),
                str(calc.aggravating_coefficient),
                str(calc.initial_score),
                f"{int(calc.mitigation_credit*100)}%",
                str(calc.residual_score),
                calc.risk_class.value,
            ]
            for c, v in enumerate(values):
                fill = BRAND_BG
                color = BRAND_NAVY
                bold = False
                if c == 2:
                    fill = RISK_LABEL_FILL.get(risk, BRAND_BG)
                    bold = True
                if c == 9:
                    fill = RISK_CLASS_FILL.get(calc.risk_class, BRAND_BG)
                    color = RISK_CLASS_TEXT.get(calc.risk_class, BRAND_NAVY)
                    bold = True
                set_cell(table.cell(r, c), v, fill=fill, color=color, bold=bold, align="center" if c >= 2 else "left")
        add_h3(doc, "Dettaglio componenti e misure")
        for calc in calculations.get(site.nome, []):
            add_callout(doc, f"{calc.employee_label} - {calc.mansione}", f"Classe residua {calc.risk_class.value}; stato operativo {calc.operational_status.value}; ripresa prevista {calc.resume_time or 'n.d.'}.", RISK_CLASS_FILL.get(calc.risk_class, BRAND_LIGHT), RISK_CLASS_TEXT.get(calc.risk_class, BRAND_NAVY))
            for action in calc.recommended_actions[:6]:
                add_check_item(doc, action)


def add_legal_decision_section(doc: Document, payload: DVRInput, risks: Dict[str, RiskLabel]) -> None:
    add_h1(doc, "Applicazione Ordinanza Lombardia e decisione operativa")
    doc.add_paragraph("La valutazione applica la regola dell'ordinanza solo quando coincidono data, territorio, settore, esposizione prolungata al sole e rischio Worklimate ALTO per lavoratori esposti al sole con attività fisica intensa. La valutazione aziendale resta necessaria anche quando il divieto non è formalmente attivo.")
    table = doc.add_table(rows=1 + len(payload.sites), cols=7)
    style_table(table)
    fill_header(table, ["Sito", "Regione", "Settore target", "Periodo", "Sole", "Worklimate", "Esito"])
    for r, site in enumerate(payload.sites, start=1):
        risk = risks.get(site.nome, RiskLabel.non_disponibile)
        lt = legal_trigger(site, risk, payload.assessment_date)
        values = [
            site.nome,
            site.regione,
            yesno(site.settore.value in {"agricoltura", "florovivaismo", "edilizia_outdoor", "cave"}),
            "10/06-23/09/2026" if payload.assessment_date.year == 2026 else fmt_date(payload.assessment_date),
            yesno(site.esposizione_prolungata_sole),
            risk.value,
            "STOP 12:30-16:00" if lt.divieto_1230_1600 else lt.messaggio,
        ]
        for c, v in enumerate(values):
            fill = BRAND_BG
            color = BRAND_NAVY
            if c == 6 and lt.divieto_1230_1600:
                fill, color = BRAND_RED, WHITE
            set_cell(table.cell(r, c), v, fill=fill, color=color, bold=c == 6)
    add_callout(doc, "Ripresa attività", "Se lo stop è attivo tra 12:30 e 16:00, la ripresa non è automatica: eseguire check di ripartenza dalle 16:00, verificare condizioni dei lavoratori, acqua, ombra, pause, preposto e possibilità di ridurre lo sforzo fisico.", "FECACA", "991B1B")


def add_prevention_measures_section(doc: Document, payload: DVRInput, calculations: Dict[str, list[WorkerCalculation]], risks: Dict[str, RiskLabel]) -> None:
    add_h1(doc, "Misure di prevenzione e protezione")
    doc.add_paragraph("Le misure sono organizzative, tecniche e procedurali. Devono essere pianificate prima del turno, confermate dal preposto e registrate quando il rischio è medio/alto o quando è attivo il divieto operativo.")
    measures = [
        ("Programmazione orari", "Anticipare lavorazioni gravose nelle ore fresche; evitare ore centrali; programmare eventuali deroghe acustiche comunali se necessarie."),
        ("Acqua", "Garantire acqua fresca vicino all'area di lavoro, con reintegro e accessibilità continua."),
        ("Ombra/recupero", "Predisporre zone ombreggiate o aree fresche per pause e recupero termico."),
        ("Pause", "Definire frequenza pause proporzionata a rischio, carico fisico, acclimatazione e indicazioni medico competente."),
        ("Rotazione", "Ridurre esposizione individuale alternando mansioni esposte/non esposte."),
        ("Preposto", "Controllo attivo dei sintomi sentinella e registrazione decisioni operative."),
        ("DPI", "Ridurre carico termico degli indumenti compatibilmente con la protezione obbligatoria."),
        ("Lavoratori suscettibili", "Gestire solo prescrizioni operative, senza riportare diagnosi o dettagli sanitari nel DVR."),
        ("Emergenza", "Procedura colpo di calore con stop immediato, raffreddamento, chiamata soccorsi, informazione a datore/preposto."),
    ]
    table = doc.add_table(rows=1 + len(measures), cols=3)
    style_table(table)
    fill_header(table, ["Area", "Misura", "Evidenza richiesta"])
    for r, (area, measure) in enumerate(measures, start=1):
        set_cell(table.cell(r, 0), area, fill=BRAND_LIGHT, color=BRAND_NAVY, bold=True)
        set_cell(table.cell(r, 1), measure)
        set_cell(table.cell(r, 2), "Registro operativo / checklist preposto / foto / firma")


def add_daily_procedure_section(doc: Document) -> None:
    add_h1(doc, "Procedura operativa giornaliera")
    steps = [
        ("Prima dell'avvio turno", "Verificare previsioni, personale, mansioni gravose, acqua, ombra, pause, aree alternative e preposto."),
        ("Ore 10:00-12:00", "Aggiornare verifica Worklimate/portale e condizioni locali; comunicare eventuale stop programmato."),
        ("Ore 12:30-16:00", "Se divieto attivo: sospendere/riprogrammare attività in esposizione prolungata al sole; svolgere solo attività alternative compatibili."),
        ("Dopo le 16:00", "Eseguire check di ripartenza e mantenere misure rafforzate se il rischio residuo è medio/alto."),
        ("Fine turno", "Archiviare registro, eventuali screenshot, firma preposto, anomalie e azioni correttive."),
    ]
    table = doc.add_table(rows=1 + len(steps), cols=3)
    style_table(table)
    fill_header(table, ["Momento", "Azione", "Responsabile"])
    for r, (moment, action) in enumerate(steps, start=1):
        set_cell(table.cell(r, 0), moment, fill=BRAND_LIGHT, color=BRAND_NAVY, bold=True)
        set_cell(table.cell(r, 1), action)
        set_cell(table.cell(r, 2), "Datore di lavoro / Preposto / RSPP")



def add_mobile_alerts_section(doc: Document, payload: DVRInput, risks: Dict[str, RiskLabel]) -> None:
    add_h1(doc, "Sistema di allerta operativa e tracciabilità giornaliera")
    doc.add_paragraph(
        "Il sistema Safe 4 U Heat Check supporta datore di lavoro, preposto e operatori autorizzati tramite allert locali sul telefono. "
        "Le notifiche non sostituiscono la valutazione del rischio: servono a ricordare i controlli obbligatori, la verifica Worklimate, "
        "l'eventuale stop operativo, la ripresa e la registrazione delle misure adottate."
    )
    settings = payload.alert_settings or {}
    config_rows = [
        ("Allerte attive", yesno(bool(settings.get("enabled")))),
        ("Responsabile allert", settings.get("responsible") or payload.company.preposto or payload.company.datore_lavoro or "Da definire"),
        ("Canale escalation", settings.get("escalation_channel") or payload.company.email_referente or "Da definire"),
        ("Modalità", settings.get("mode") or "Solo oggi / da configurare nel sistema"),
        ("Intervallo monitoraggio", f"{settings.get('monitor_interval_minutes', 0)} minuti" if settings else "Da definire"),
    ]
    cfg = doc.add_table(rows=1 + len(config_rows), cols=2)
    style_table(cfg)
    fill_header(cfg, ["Parametro", "Configurazione"])
    for r, (k, v) in enumerate(config_rows, start=1):
        set_cell(cfg.cell(r, 0), k, fill=BRAND_LIGHT, color=BRAND_NAVY, bold=True)
        set_cell(cfg.cell(r, 1), str(v))

    plan = payload.alert_plan or default_mobile_alert_plan(payload, risks)
    add_h2(doc, "Piano allerte consigliato")
    t = doc.add_table(rows=1 + len(plan), cols=5)
    style_table(t)
    fill_header(t, ["Ora", "Allert", "Quando scatta", "Azione richiesta", "Priorità"])
    for r, item in enumerate(plan, start=1):
        severity = str(item.get("severity", "info"))
        fill = BRAND_RED if severity == "danger" else ("FEF3C7" if severity == "warning" else BRAND_BG)
        color = WHITE if severity == "danger" else BRAND_NAVY
        set_cell(t.cell(r, 0), str(item.get("time", "-")), fill=fill, color=color, bold=True)
        set_cell(t.cell(r, 1), str(item.get("title", "Allert operativo")))
        set_cell(t.cell(r, 2), str(item.get("trigger", item.get("body", "Controllo programmato"))))
        set_cell(t.cell(r, 3), str(item.get("action", item.get("body", "Eseguire verifica e salvare registro"))))
        set_cell(t.cell(r, 4), "Alta" if severity in {"danger", "warning"} else "Media", fill=fill, color=color, bold=True)
    add_callout(doc, "Uso corretto delle notifiche", "Le notifiche devono generare evidenza operativa: screenshot Worklimate, check misure, eventuale stop/rimodulazione, ora ripresa, nominativo preposto e firma/validazione nel registro giornaliero.", BRAND_LIGHT, BRAND_NAVY)


def default_mobile_alert_plan(payload: DVRInput, risks: Dict[str, RiskLabel]) -> list[dict]:
    legal_active = any(legal_trigger(site, risks.get(site.nome, RiskLabel.non_disponibile), payload.assessment_date).divieto_1230_1600 for site in payload.sites)
    risk_high = any(risks.get(site.nome, RiskLabel.non_disponibile) == RiskLabel.alto for site in payload.sites)
    return [
        {"time": "10:30", "title": "Pre-check rischio caldo", "trigger": "Prima della fascia critica", "action": "Verificare acqua, ombra, pause, rotazione addetti, preposto e lavoratori non acclimatati.", "severity": "info"},
        {"time": "12:00", "title": "Verifica Worklimate", "trigger": "Mappa ore 12:00 lavoratori al sole con attività intensa", "action": "Registrare livello rischio e allegare evidenza/screenshot.", "severity": "warning" if risk_high else "info"},
        {"time": "12:20", "title": "Preavviso fascia critica", "trigger": "Possibile stop 12:30", "action": "Comunicare alla squadra sospensione/rimodulazione se condizioni ordinanza attive.", "severity": "danger" if legal_active else "warning"},
        {"time": "12:30", "title": "Stop operativo / controllo rafforzato", "trigger": "Fascia 12:30-16:00", "action": "Se stop attivo: sospendere attività in esposizione prolungata al sole; altrimenti confermare misure rafforzate.", "severity": "danger" if legal_active else "warning"},
        {"time": "16:00", "title": "Check ripresa lavoro", "trigger": "Fine fascia vietata", "action": "Eseguire nuova verifica prima della ripresa e mantenere misure rafforzate se rischio residuo medio/alto.", "severity": "warning"},
    ]

def add_emergency_section(doc: Document) -> None:
    add_h1(doc, "Gestione emergenza caldo")
    add_callout(doc, "Sintomi sentinella", "Crampi, debolezza marcata, vertigini, nausea, confusione, cute calda, difficoltà di coordinamento, perdita di coscienza o peggioramento improvviso richiedono stop immediato e attivazione procedura.", "FEF3C7", "92400E")
    for step in [
        "Interrompere immediatamente l'attività e spostare il lavoratore in zona ombreggiata/fresca.",
        "Allertare preposto e addetti primo soccorso; chiamare 112/118 se sintomi importanti o non rapida risoluzione.",
        "Raffreddare il corpo con mezzi disponibili, rimuovere indumenti non necessari e monitorare coscienza/respirazione.",
        "Registrare evento, condizioni operative e misure correttive; rivalutare DVR se evento sentinella significativo.",
    ]:
        add_check_item(doc, step)


def add_training_health_section(doc: Document) -> None:
    add_h1(doc, "Informazione, formazione, addestramento e sorveglianza sanitaria")
    paragraphs = [
        "I lavoratori e i preposti devono ricevere informazione sui rischi da calore/radiazione solare, sulle misure adottate, sui sintomi da stress termico, sull'idratazione, sulle pause, sulla segnalazione precoce e sulle procedure di emergenza.",
        "Il Medico Competente, ove nominato, collabora alla valutazione per la gestione dei lavoratori più suscettibili, fornendo prescrizioni operative senza che diagnosi, farmaci o patologie siano riportati nel DVR.",
        "Per neoassunti, lavoratori stagionali o non acclimatati, prevedere progressione dell'esposizione, affiancamento e maggior controllo del preposto.",
    ]
    for text in paragraphs:
        doc.add_paragraph(text)


def add_monitoring_section(doc: Document, payload: DVRInput, risks: Dict[str, RiskLabel]) -> None:
    add_h1(doc, "Monitoraggio, registrazioni e piano di miglioramento")
    table = doc.add_table(rows=6, cols=5)
    style_table(table)
    fill_header(table, ["Azione", "Priorità", "Responsabile", "Scadenza", "Stato"])
    rows = [
        ("Usare sistema Safe 4 U Heat Check per registro giornaliero", "Alta", "Datore/Preposto", "Immediata", "Da avviare"),
        ("Allegare screenshot Worklimate nei giorni critici", "Alta", "Preposto", "Ogni verifica", "Da attuare"),
        ("Mappare zone ombra/acqua e aree alternative", "Media", "RSPP/Preposto", "Prima dei picchi", "Da completare"),
        ("Definire turnazione e pause per mansioni intense", "Alta", "Datore/Preposto", "Prima del turno", "Da attuare"),
        ("Verificare efficacia misure e aggiornare DVR", "Media", "Datore/RSPP", "Periodica/evento", "Pianificata"),
    ]
    for r, row in enumerate(rows, start=1):
        for c, v in enumerate(row):
            fill = "FECACA" if c == 1 and v == "Alta" else BRAND_BG
            set_cell(table.cell(r, c), v, fill=fill, color=BRAND_NAVY, bold=c == 1)


def add_attachment_gallery(doc: Document, payload: DVRInput) -> None:
    images = [a for a in payload.documents if a.data_url and (a.mime_type or "").startswith("image/")]
    if not images:
        return
    add_h1(doc, "Evidenze fotografiche e planimetriche")
    doc.add_paragraph("Le immagini acquisite sono richiamate come evidenze tecniche: screenshot Worklimate, planimetrie, zone d'ombra, punti acqua, aree di recupero, layout cantiere e misure organizzative presenti.")
    for idx, attachment in enumerate(images[:8], start=1):
        data = data_url_to_bytes(attachment.data_url)
        if data:
            try:
                p = doc.add_paragraph()
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                p.add_run().add_picture(BytesIO(data), width=Inches(5.9))
                cap = doc.add_paragraph()
                cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
                rr = cap.add_run(f"Evidenza {idx} - {attachment.filename} ({attachment.category.value})")
                rr.italic = True
                rr.font.size = Pt(8.5)
                rr.font.color.rgb = RGBColor.from_string(BRAND_GRAY)
            except Exception:
                continue


def add_conclusions_section(doc: Document, payload: DVRInput, calculations: Dict[str, list[WorkerCalculation]], risks: Dict[str, RiskLabel]) -> None:
    add_h1(doc, "Conclusioni")
    max_class = max_risk_from_calculations(calculations)
    ban_count = count_legal_bans(payload, risks)
    text = (
        f"In base ai dati inseriti, alle condizioni dei siti e alle misure dichiarate, il rischio residuo massimo risulta {max_class.value}. "
        "La gestione operativa deve essere integrata nel DVR aziendale, comunicata ai preposti e registrata giornalmente durante il periodo estivo o in occasione di ondate di calore. "
    )
    if ban_count:
        text += "Nei casi in cui si attiva il divieto previsto dall'Ordinanza Lombardia, le attività in esposizione prolungata al sole devono essere sospese/rimodulate nella fascia 12:30-16:00 e la ripresa deve avvenire non prima delle 16:00 previa nuova verifica. "
    else:
        text += "Alla data e per i dati valutati non risulta attivo lo stop operativo da ordinanza; restano valide le misure aziendali di prevenzione e il principio di cautela. "
    text += "Il documento è soggetto ad aggiornamento in caso di mutamenti organizzativi, introduzione di nuove mansioni, cambio sede/cantiere, variazione normativa, evento sentinella o indicazione del Medico Competente."
    doc.add_paragraph(text)
    if payload.conclusions_notes:
        add_h2(doc, "Conclusioni integrative del consulente")
        doc.add_paragraph(payload.conclusions_notes)


def add_signature_section(doc: Document, payload: DVRInput) -> None:
    add_h1(doc, "Sottoscrizione")
    doc.add_paragraph("Il presente documento deve essere approvato e sottoscritto secondo l'organizzazione aziendale, previa consultazione dei soggetti della prevenzione.")
    roles = [
        ("Datore di lavoro", payload.company.datore_lavoro or ""),
        ("RSPP", payload.company.rspp or ""),
        ("Medico competente", payload.company.medico_competente or ""),
        ("RLS/RLST", payload.company.rls or ""),
        ("Preposto/Referente", payload.company.preposto or payload.company.referente_operativo or ""),
        ("Consulente Safe 4 U", payload.prepared_by or ""),
    ]
    table = doc.add_table(rows=1 + len(roles), cols=3)
    style_table(table)
    fill_header(table, ["Figura", "Nominativo", "Firma"])
    for r, (role, name) in enumerate(roles, start=1):
        set_cell(table.cell(r, 0), role, fill=BRAND_LIGHT, color=BRAND_NAVY, bold=True)
        set_cell(table.cell(r, 1), name or "Da completare")
        set_cell(table.cell(r, 2), "\n\n")
    doc.add_paragraph(f"Luogo e data: ______________________, {fmt_date(payload.assessment_date)}")


def add_appendices(doc: Document, payload: DVRInput, calculations: Dict[str, list[WorkerCalculation]], risks: Dict[str, RiskLabel]) -> None:
    """Deprecated: the final DVR does not print client collection forms as appendices.
    Client forms are distributed separately through the application and stored in the technical file.
    """
    return


# Charts ------------------------------------------------------------------

def chart_timeline(legal_active: bool) -> bytes:
    fig, ax = plt.subplots(figsize=(8.5, 1.6), dpi=160)
    ax.set_xlim(6, 20)
    ax.set_ylim(0, 1)
    segments = [(6, 4, "#16A34A", "06-10\npreferibile"), (10, 2.5, "#FACC15", "10-12:30\ncontrollo"), (12.5, 3.5, "#DC2626" if legal_active else "#F97316", "12:30-16\nSTOP" if legal_active else "12:30-16\ncritica"), (16, 4, "#16A34A" if not legal_active else "#FACC15", "16-20\nripresa/check")]
    for x, w, color, label in segments:
        ax.broken_barh([(x, w)], (0.25, 0.5), facecolors=color, edgecolors="#111A4C")
        ax.text(x + w/2, 0.5, label, ha="center", va="center", fontsize=8, color="#111A4C", fontweight="bold")
    ax.set_yticks([])
    ax.set_xticks([6, 10, 12.5, 16, 20])
    ax.set_xticklabels(["06:00", "10:00", "12:30", "16:00", "20:00"], fontsize=8)
    ax.set_title("Timeline operativa rischio caldo", fontsize=10, color="#111A4C", fontweight="bold")
    for spine in ax.spines.values():
        spine.set_visible(False)
    fig.tight_layout()
    return fig_to_png(fig)


def chart_risk_matrix() -> bytes:
    fig, ax = plt.subplots(figsize=(5.4, 4.2), dpi=160)
    ax.set_xlim(0.5, 4.5)
    ax.set_ylim(0.5, 4.5)
    for p in range(1, 5):
        for d in range(1, 5):
            score = p * d
            if score <= 4:
                color = "#BBF7D0"
            elif score <= 8:
                color = "#FEF3C7"
            elif score <= 12:
                color = "#FED7AA"
            else:
                color = "#FECACA"
            rect = plt.Rectangle((p-0.5, d-0.5), 1, 1, facecolor=color, edgecolor="#111A4C")
            ax.add_patch(rect)
            ax.text(p, d, str(score), ha="center", va="center", fontsize=10, fontweight="bold", color="#111A4C")
    ax.set_xticks([1, 2, 3, 4])
    ax.set_yticks([1, 2, 3, 4])
    ax.set_xlabel("P - Probabilità/esposizione", fontsize=9)
    ax.set_ylabel("D - Danno potenziale", fontsize=9)
    ax.set_title("Matrice P x D prima dei coefficienti", fontsize=10, color="#111A4C", fontweight="bold")
    fig.tight_layout()
    return fig_to_png(fig)


def chart_risk_bars(calcs: List[WorkerCalculation]) -> bytes:
    labels = [short_label(c.mansione or c.employee_label) for c in calcs[:10]]
    values = [c.residual_score for c in calcs[:10]]
    colors = ["#16A34A" if v <= 4 else "#FACC15" if v <= 8 else "#F97316" if v <= 12 else "#DC2626" for v in values]
    fig, ax = plt.subplots(figsize=(8.5, max(2.5, 0.38 * len(labels) + 1)), dpi=160)
    y = list(range(len(labels)))
    ax.barh(y, values, color=colors, edgecolor="#111A4C")
    ax.set_yticks(y)
    ax.set_yticklabels(labels, fontsize=8)
    ax.invert_yaxis()
    ax.axvline(4, color="#64748B", linestyle="--", linewidth=0.8)
    ax.axvline(8, color="#64748B", linestyle="--", linewidth=0.8)
    ax.axvline(12, color="#64748B", linestyle="--", linewidth=0.8)
    ax.set_xlabel("Indice operativo residuo", fontsize=9)
    ax.set_title("Rischio residuo per mansione/gruppo", fontsize=10, color="#111A4C", fontweight="bold")
    fig.tight_layout()
    return fig_to_png(fig)


def chart_before_after(calcs: List[WorkerCalculation]) -> bytes:
    labels = [short_label(c.mansione or c.employee_label) for c in calcs[:8]]
    initial = [c.initial_score for c in calcs[:8]]
    residual = [c.residual_score for c in calcs[:8]]
    x = range(len(labels))
    fig, ax = plt.subplots(figsize=(8.5, 3.4), dpi=160)
    width = 0.38
    ax.bar([i - width/2 for i in x], initial, width, label="iniziale", color="#F97316", edgecolor="#111A4C")
    ax.bar([i + width/2 for i in x], residual, width, label="residuo", color="#1D4ED8", edgecolor="#111A4C")
    ax.set_xticks(list(x))
    ax.set_xticklabels(labels, rotation=20, ha="right", fontsize=8)
    ax.set_ylabel("Indice operativo", fontsize=9)
    ax.set_title("Riduzione rischio dopo misure", fontsize=10, color="#111A4C", fontweight="bold")
    ax.legend(fontsize=8)
    fig.tight_layout()
    return fig_to_png(fig)


def fig_to_png(fig) -> bytes:
    buf = BytesIO()
    fig.savefig(buf, format="png", bbox_inches="tight", transparent=False)
    plt.close(fig)
    buf.seek(0)
    return buf.getvalue()


def add_picture_from_bytes(doc: Document, data: bytes, caption: str) -> None:
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run().add_picture(BytesIO(data), width=Inches(6.2))
    cap = doc.add_paragraph()
    cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = cap.add_run(caption)
    r.italic = True
    r.font.size = Pt(8.5)
    r.font.color.rgb = RGBColor.from_string(BRAND_GRAY)


# Utility -----------------------------------------------------------------

def risk_by_site(payload: DVRInput) -> Dict[str, RiskLabel]:
    result = {site.nome: RiskLabel.non_disponibile for site in payload.sites}
    for wr in payload.worklimate_results:
        if not wr.site_name:
            continue
        risk = max_risk_label([d.label for d in wr.days])
        result[wr.site_name] = risk
    return result


def max_risk_label(labels: Iterable[RiskLabel]) -> RiskLabel:
    rank = {RiskLabel.non_disponibile: 0, RiskLabel.basso: 1, RiskLabel.moderato: 2, RiskLabel.alto: 3}
    out = RiskLabel.non_disponibile
    for label in labels:
        if rank[label] > rank[out]:
            out = label
    return out


def max_risk_from_calculations(calculations: Dict[str, list[WorkerCalculation]]) -> RiskClass:
    all_calcs = [c for arr in calculations.values() for c in arr]
    return dominant_risk(all_calcs) if all_calcs else RiskClass.basso


def max_status_from_calculations(calculations: Dict[str, list[WorkerCalculation]]):
    all_calcs = [c for arr in calculations.values() for c in arr]
    return highest_operational_status(all_calcs) if all_calcs else "GRIGIO"


def count_legal_bans(payload: DVRInput, risks: Dict[str, RiskLabel]) -> int:
    return sum(1 for site in payload.sites if legal_trigger(site, risks.get(site.nome, RiskLabel.non_disponibile), payload.assessment_date).divieto_1230_1600)


def collect_priority_actions(calculations: Dict[str, list[WorkerCalculation]], payload: DVRInput, risks: Dict[str, RiskLabel]) -> List[str]:
    actions: List[str] = []
    for site in payload.sites:
        risk = risks.get(site.nome, RiskLabel.non_disponibile)
        lt = legal_trigger(site, risk, payload.assessment_date)
        if lt.divieto_1230_1600:
            actions.append(f"{site.nome}: sospendere/riprogrammare attività esposte al sole 12:30-16:00; ripresa dalle 16:00 previa nuova verifica.")
        for calc in calculations.get(site.nome, []):
            for action in calc.recommended_actions:
                actions.append(f"{calc.employee_label}: {action}")
    return list(dict.fromkeys(actions))


def data_url_to_bytes(data_url: Optional[str]) -> Optional[bytes]:
    if not data_url:
        return None
    try:
        if "," in data_url:
            data_url = data_url.split(",", 1)[1]
        return base64.b64decode(data_url)
    except Exception:
        return None


def style_table(table) -> None:
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True
    for row in table.rows:
        for cell in row.cells:
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            set_cell_margin(cell, 80, 80, 80, 80)
            for p in cell.paragraphs:
                for run in p.runs:
                    run.font.size = Pt(8.5)


def fill_header(table, headers: List[str]) -> None:
    for i, h in enumerate(headers):
        set_cell(table.cell(0, i), h, fill=BRAND_NAVY, color=WHITE, bold=True, align="center")


def set_cell(cell, text: str, fill: Optional[str] = None, color: str = BRAND_NAVY, bold: bool = False, align: str = "left") -> None:
    cell.text = ""
    p = cell.paragraphs[0]
    p.alignment = {"left": WD_ALIGN_PARAGRAPH.LEFT, "center": WD_ALIGN_PARAGRAPH.CENTER, "right": WD_ALIGN_PARAGRAPH.RIGHT}.get(align, WD_ALIGN_PARAGRAPH.LEFT)
    run = p.add_run(str(text))
    run.font.size = Pt(8.5)
    run.font.color.rgb = RGBColor.from_string(color)
    run.font.bold = bold
    if fill:
        set_cell_shading(cell, fill)


def set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margin(cell, top: int, start: int, bottom: int, end: int) -> None:
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for m, v in [("top", top), ("start", start), ("bottom", bottom), ("end", end)]:
        node = tc_mar.find(qn(f"w:{m}"))
        if node is None:
            node = OxmlElement(f"w:{m}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(v))
        node.set(qn("w:type"), "dxa")


def add_h1(doc: Document, text: str) -> None:
    p = doc.add_paragraph(text, style="Heading 1")
    add_bottom_border(p, BRAND_GOLD)


def add_h2(doc: Document, text: str) -> None:
    doc.add_paragraph(text, style="Heading 2")


def add_h3(doc: Document, text: str) -> None:
    doc.add_paragraph(text, style="Heading 3")


def add_bottom_border(paragraph, color: str) -> None:
    p = paragraph._p
    p_pr = p.get_or_add_pPr()
    p_bdr = p_pr.find(qn("w:pBdr"))
    if p_bdr is None:
        p_bdr = OxmlElement("w:pBdr")
        p_pr.append(p_bdr)
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), "8")
    bottom.set(qn("w:space"), "3")
    bottom.set(qn("w:color"), color)
    p_bdr.append(bottom)


def add_callout(doc: Document, title: str, text: str, fill: str, color: str) -> None:
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = table.cell(0, 0)
    set_cell_shading(cell, fill)
    p = cell.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    rt = p.add_run(title + ": ")
    rt.bold = True
    rt.font.color.rgb = RGBColor.from_string(color)
    rt.font.size = Pt(9.5)
    rb = p.add_run(text)
    rb.font.color.rgb = RGBColor.from_string(color)
    rb.font.size = Pt(9)
    set_cell_margin(cell, 140, 140, 140, 140)


def add_warning_box(doc: Document, title: str, text: str) -> None:
    add_callout(doc, title, text, "FEF3C7", "92400E")


def add_small_note(doc: Document, text: str) -> None:
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.italic = True
    r.font.size = Pt(8.5)
    r.font.color.rgb = RGBColor.from_string(BRAND_GRAY)


def add_check_item(doc: Document, text: str) -> None:
    p = doc.add_paragraph(style="List Bullet")
    r = p.add_run(text)
    r.font.size = Pt(9.5)


def fmt_date(d: date) -> str:
    return d.strftime("%d/%m/%Y")


def yesno(v: bool) -> str:
    return "Sì" if v else "No"


def format_bytes(v: Optional[int]) -> str:
    if v is None:
        return "n.d."
    if v < 1024:
        return f"{v} B"
    if v < 1024**2:
        return f"{v/1024:.1f} KB"
    return f"{v/1024**2:.1f} MB"


def sector_label(value: str) -> str:
    return {
        "agricoltura": "Agricoltura",
        "florovivaismo": "Florovivaismo",
        "edilizia_outdoor": "Cantieri edili all'aperto",
        "cave": "Cave",
        "logistica_piazzali": "Logistica/piazzali",
        "indoor_non_climatizzato": "Indoor non climatizzato",
        "manutenzioni_esterne": "Manutenzioni esterne",
        "altro": "Altro",
    }.get(value, value)


def short_label(value: str, max_len: int = 28) -> str:
    clean = re.sub(r"\s+", " ", value).strip()
    return clean if len(clean) <= max_len else clean[: max_len - 1] + "…"

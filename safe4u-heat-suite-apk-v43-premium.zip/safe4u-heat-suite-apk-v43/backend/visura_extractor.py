from __future__ import annotations

import re
from io import BytesIO
from typing import Dict

from pypdf import PdfReader


def extract_text(filename: str, content: bytes) -> str:
    lower = filename.lower()
    if lower.endswith(".pdf") or content[:4] == b"%PDF":
        reader = PdfReader(BytesIO(content))
        text_parts = []
        for page in reader.pages[:8]:
            text_parts.append(page.extract_text() or "")
        return "\n".join(text_parts)
    try:
        return content.decode("utf-8", errors="ignore")
    except Exception:
        return ""


def first_match(patterns: list[str], text: str) -> str | None:
    for pattern in patterns:
        m = re.search(pattern, text, re.I | re.M)
        if m:
            return " ".join(m.group(1).strip().split())
    return None


def extract_company_from_upload(filename: str, content: bytes) -> Dict[str, object]:
    text = extract_text(filename, content)
    normalized = re.sub(r"[ \t]+", " ", text)
    piva = first_match([r"(?:P\.?\s*IVA|PARTITA\s+IVA)\s*[:\-]?\s*([0-9]{11})"], normalized)
    cf = first_match([r"(?:CODICE\s+FISCALE|C\.?F\.?)\s*[:\-]?\s*([A-Z0-9]{11,16})"], normalized)
    rea = first_match([r"(?:REA|R\.?E\.?A\.?)\s*[:\-]?\s*([A-Z]{1,3}\s*[-/]?\s*[0-9]{3,})"], normalized)
    ateco = first_match([r"(?:ATECO|CODICE\s+ATECO)\s*[:\-]?\s*([0-9]{2}(?:\.[0-9]{1,2}){1,3})"], normalized)
    ragione = first_match([
        r"(?:DENOMINAZIONE|RAGIONE\s+SOCIALE)\s*[:\-]?\s*([^\n\r]{3,120})",
        r"^\s*([A-Z0-9 '&\.\-]+(?:S\.R\.L\.|SRL|SOCIETA' A RESPONSABILITA LIMITATA)[^\n\r]*)",
    ], normalized)
    sede = first_match([
        r"(?:SEDE\s+LEGALE|INDIRIZZO\s+SEDE\s+LEGALE)\s*[:\-]?\s*([^\n\r]{5,180})",
        r"(?:VIA|VIALE|PIAZZA|CORSO)\s+([^\n\r]{5,160})",
    ], normalized)
    attivita = first_match([
        r"(?:ATTIVITA'\s+PREVALENTE|ATTIVITÀ\s+PREVALENTE|OGGETTO\s+SOCIALE)\s*[:\-]?\s*([^\n\r]{10,220})"
    ], normalized)
    return {
        "filename": filename,
        "company": {
            "ragione_sociale": ragione,
            "partita_iva": piva,
            "codice_fiscale": cf,
            "rea": rea,
            "sede_legale": sede,
            "ateco": ateco,
            "attivita": attivita,
        },
        "text_preview": normalized[:2500],
        "fields_found": {"ragione_sociale": bool(ragione), "partita_iva": bool(piva), "codice_fiscale": bool(cf), "rea": bool(rea), "sede_legale": bool(sede), "ateco": bool(ateco)},
    }

# Build APK - Safe 4 U Heat Check

Questa versione è predisposta per generare un APK Android tramite Capacitor.

## Output atteso

Dopo la build locale o CI:

```text
mobile-capacitor/android/app/build/outputs/apk/debug/app-debug.apk
```

Per pubblicazione o installazione esterna va generata anche la versione release firmata.

## Requisiti macchina

- Node.js 20+
- Android Studio installato
- Android SDK installato
- Java/JDK compatibile con Android Gradle Plugin
- variabile `ANDROID_HOME` configurata

## Build APK debug locale

```bash
cd mobile-capacitor
npm install
npm run cap:add:android
npm run cap:sync
cd android
./gradlew assembleDebug
```

APK debug:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

## Build APK release firmato

1. Generare keystore:

```bash
keytool -genkeypair -v \
  -keystore safe4u-heatcheck-release.keystore \
  -alias safe4u-heatcheck \
  -keyalg RSA -keysize 2048 -validity 10000
```

2. Configurare `android/gradle.properties` con credenziali keystore.
3. Eseguire:

```bash
cd android
./gradlew assembleRelease
```

APK release:

```text
android/app/build/outputs/apk/release/app-release.apk
```

## Google Play

Per Google Play è preferibile generare anche AAB:

```bash
./gradlew bundleRelease
```

Output:

```text
android/app/build/outputs/bundle/release/app-release.aab
```

## Nota tecnica

Il progetto usa solo geolocalizzazione foreground: la posizione viene richiesta quando l'utente preme il pulsante di valutazione. Le notifiche locali sono gestite da Capacitor Local Notifications.

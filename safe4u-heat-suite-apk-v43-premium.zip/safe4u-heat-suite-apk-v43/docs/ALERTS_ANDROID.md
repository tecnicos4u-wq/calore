# Allert smartphone - Safe 4 U Heat Check

## Obiettivo operativo

L'app Android deve notificare a datore di lavoro, preposto o operatore autorizzato:

- pre-check misure prima della fascia critica;
- verifica Worklimate ore 12:00;
- preavviso stop 12:20;
- stop operativo 12:30 se le condizioni ordinanza sono attive;
- check ripresa dalle 16:00;
- monitoraggi periodici su acqua, ombra, pause, rotazione e sintomi.

## Regola fondamentale

Gli allert non sostituiscono DVR, Worklimate o valutazione del datore di lavoro. Servono a rendere eseguibile e tracciabile la decisione: cosa fare, quando farlo e che evidenza salvare.

## Implementazione MVP web/PWA

Nel prototipo frontend sono implementate notifiche locali con Notification API + Service Worker. Funzionano su HTTPS/localhost e sono affidabili finché la PWA/app resta aperta. È presente un tasto test e una funzione di programmazione degli allert futuri della giornata.

## Implementazione Android Google Play

Per la build Android usare notifiche locali native persistenti:

- Capacitor Local Notifications o equivalente Flutter;
- permesso POST_NOTIFICATIONS per Android 13+;
- niente geolocalizzazione background;
- notifiche programmate localmente sul dispositivo dopo il check rischio;
- tap sulla notifica apre schermata “Valutazione/Registro giornaliero”.

## Canali Android consigliati

- `heat-critical`: stop operativo e preavvisi rossi;
- `heat-check`: verifiche Worklimate e monitoraggi;
- `heat-register`: promemoria salvataggio registro.

## Tracciabilità

Ogni allert critico deve permettere di generare una riga di registro con:

- data e ora;
- sito/cantiere;
- livello Worklimate;
- esito app;
- misure confermate;
- eventuale stop/ripresa;
- responsabile;
- firma semplice o conferma preposto.

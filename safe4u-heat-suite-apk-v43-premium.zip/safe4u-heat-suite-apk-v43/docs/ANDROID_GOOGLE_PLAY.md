# Roadmap Android / Google Play

L'app è impostata come PWA mobile-first e può essere portata su Android con Capacitor.

## Scelta consigliata

- React/TypeScript o frontend attuale refactorizzato in componenti.
- Capacitor per build Android.
- Permesso geolocalizzazione solo foreground, richiesto quando l'utente preme "Usa posizione telefono" o "Valuta se posso lavorare".
- Nessuna posizione in background.
- Inserimento manuale luogo se l'utente nega il GPS.

## Preparazione Play Store

- privacy policy;
- dichiarazione Data Safety;
- descrizione uso posizione;
- account sviluppatore;
- Android App Bundle `.aab`;
- test interno, chiuso, produzione.

## Permessi

Richiedere solo:

- accesso posizione precisa/approssimata in primo piano;
- accesso file tramite picker, senza lettura indiscriminata storage;
- eventualmente fotocamera in futuro solo per allegare foto area ombra/acqua.


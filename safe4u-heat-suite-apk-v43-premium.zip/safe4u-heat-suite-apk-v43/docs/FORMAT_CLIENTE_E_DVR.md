# Format cliente e DVR finale

## Decisione progettuale

Il DVR finale non deve stampare l'elenco dei format A-G come se fossero allegati burocratici.

I format A-G sono strumenti di raccolta dati da inviare al cliente. Il cliente li compila e li restituisce; il consulente li carica nell'app tramite drag & drop. Il DVR usa i dati estratti e le evidenze tecniche, ma deve apparire come documento redatto professionalmente dal consulente.

## Format disponibili

- 00 - Istruzioni cliente
- A - Dati aziendali e visura camerale
- B - Evidenza Worklimate
- C - Lavoratori o gruppi omogenei
- D - Registro giornaliero rischio calore
- E - Checklist preposto acqua/ombra/pause/stop/ripresa
- F - Procedura emergenza caldo e informativa lavoratori
- G - Foto, planimetrie e misure presenti

## Flusso app

1. Il consulente scarica il pacchetto ZIP dei format dalla schermata Documenti.
2. Invia i format pertinenti al cliente.
3. Il cliente compila e restituisce file e immagini.
4. Il consulente trascina i file nell'area drag & drop.
5. L'app classifica documenti e immagini.
6. Il DVR viene generato senza riportare l'elenco A-G: riporta solo informazioni, calcoli, evidenze tecniche, immagini, misure e conclusioni.

## Regola redazionale DVR

Nel DVR usare formulazioni come:

> La valutazione è stata elaborata sulla base della documentazione resa disponibile dal Datore di Lavoro e delle evidenze tecniche acquisite.

Evitare formulazioni come:

> Allegato A, Allegato B, Allegato C...

oppure:

> Documenti caricati in drag & drop...

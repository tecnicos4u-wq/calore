# Scaffold Capacitor per notifiche native Android

Dipendenze consigliate:

```bash
npm install @capacitor/core @capacitor/cli @capacitor/android @capacitor/local-notifications
npx cap init "Safe 4 U Heat Check" "it.safe4u.heatcheck" --web-dir frontend
npx cap add android
```

Esempio bridge:

```ts
import { LocalNotifications } from '@capacitor/local-notifications';

export async function requestNativeNotifications() {
  const permission = await LocalNotifications.requestPermissions();
  return permission.display === 'granted';
}

export async function scheduleHeatAlert(alert: {
  id: number;
  title: string;
  body: string;
  when: Date;
}) {
  await LocalNotifications.schedule({
    notifications: [{
      id: alert.id,
      title: alert.title,
      body: alert.body,
      schedule: { at: alert.when },
      channelId: alert.title.includes('STOP') ? 'heat-critical' : 'heat-check',
      ongoing: false,
      autoCancel: true
    }]
  });
}
```

Per Google Play: compilare privacy policy e Data Safety; dichiarare solo posizione foreground e notifiche. Non richiedere background location.

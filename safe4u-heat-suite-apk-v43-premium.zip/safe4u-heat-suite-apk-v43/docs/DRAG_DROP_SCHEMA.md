# Schema documenti drag & drop

Categorie supportate:

- visura_camerale
- dvr_generale
- ordinanza
- screenshot_worklimate
- elenco_lavoratori
- planimetria_o_layout
- foto_misure
- nomine_sicurezza
- procedure
- altro

Ogni allegato viene registrato con:

- id;
- filename;
- category;
- mime_type;
- size_bytes;
- description;
- data_url opzionale per immagini da incorporare nel DVR;
- extracted_text_preview opzionale.

Per privacy e peso pratica, il backend non deve conservare dati sanitari e non deve incorporare file PDF pesanti nel DOCX; li registra come allegati/documenti a supporto. Le immagini leggere possono essere incorporate come evidenza grafica.

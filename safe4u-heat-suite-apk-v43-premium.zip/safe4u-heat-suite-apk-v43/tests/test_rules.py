from datetime import date

from backend.models import Employee, PhysicalLoad, RiskLabel, Sector, Site, SunExposure
from backend.rules import calculation_for_worker, legal_trigger, humidex_from_temp_rh, wbgt_from_site


def test_lombardia_ordinanza_triggers_stop():
    site = Site(nome="Cantiere", regione="Lombardia", settore=Sector.edilizia_outdoor, esposizione_prolungata_sole=True)
    result = legal_trigger(site, RiskLabel.alto, date(2026, 7, 15))
    assert result.divieto_1230_1600 is True
    assert result.fascia_divieto == "12:30-16:00"


def test_lombardia_ordinanza_not_outside_period():
    site = Site(nome="Cantiere", regione="Lombardia", settore=Sector.edilizia_outdoor, esposizione_prolungata_sole=True)
    result = legal_trigger(site, RiskLabel.alto, date(2026, 10, 1))
    assert result.divieto_1230_1600 is False


def test_humidex_and_wbgt_are_calculated():
    site = Site(nome="Cantiere", settore=Sector.edilizia_outdoor, temperatura_c=35, umidita_relativa=50, tnw_c=27, tg_c=41)
    assert humidex_from_temp_rh(35, 50) is not None
    assert wbgt_from_site(site) == round(0.7 * 27 + 0.2 * 41 + 0.1 * 35, 1)


def test_worker_calculation_red_stop():
    site = Site(nome="Cantiere", regione="Lombardia", settore=Sector.edilizia_outdoor, esposizione_prolungata_sole=True, acqua_disponibile=True, ombra_disponibile=True, pause_programmate=True)
    worker = Employee(id_lavoratore="GR-001", mansione="Muratore", carico_fisico=PhysicalLoad.intensa, esposizione_sole=SunExposure.prolungata, dpi_indumenti_pesanti=True)
    calc = calculation_for_worker(worker, site, RiskLabel.alto, date(2026, 7, 15))
    assert calc.legal_ban is True
    assert calc.operational_status.value == "ROSSO"
    assert calc.resume_time == "16:00"
